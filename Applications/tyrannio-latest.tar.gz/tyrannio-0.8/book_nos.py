#!/usr/bin/env python
import string
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.


def string_to_num_list(s):
    return map (lambda x: ord(x) - ord('0'), s) # could have errchk here...

def num_list_to_string(l):
    return string.join(map(lambda x: chr (x + ord('0')), l),"")

def calc_check (to_check, weight, modulus):
    if len(to_check) <> len (weight):
        print  to_check ,  weight, len(to_check),len(weight)
        raise "bad to_check"
    sum = reduce (lambda x,y: x + y,
                  map (lambda x,y: x * y, to_check,weight)) % modulus
    if (sum == 0):
        return 0
    check = modulus - sum
    return check

isbn_weight = range(10,1,-1)

def calc_isbn_check(isbn_wo_check):
    return calc_check(isbn_wo_check, isbn_weight, 11)

def isbn_check_to_char(check):
    if (check == 10):
        return 'X'
    return chr(check + ord('0'))
    

bookland_weight = [1,3] * 6
# and an additional 1 for the check digit

def calc_bookland_check (bookland_wo_check):
    return calc_check (bookland_wo_check, bookland_weight, 10)
                  
def bookland_to_isbn (data, plus5):
    if (plus5):
        data = data[0:-5]
    if (data[0:3] <> "978"):
        print "Not Bookland: ", data
        return (0, "")
# plans for expanding into 979 are only that, see
# http://www.bowker.com/standards/home/isbn/digitalworld.html
# despite what Prometheus Books's edition of Taslima Nasrim's "Shame" thinks.
    if len (data) <> 13:
        return (0, "")
    data_list = string_to_num_list (data)
    check = calc_bookland_check (data_list[0:12])
    if data_list[12] <> check:
        print "bad check", data, check
    isbn_check = calc_isbn_check(data_list[3:12])
    isbn = num_list_to_string(data_list[3:12]) +isbn_check_to_char(isbn_check)
    return (1, isbn)

# XXX add unit tests for ISBN/EAN decoding
