#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import re

import string

#  parses/unparses call #s.  See http://www.oclc.org/bib/050.htm.  We use
#  a tuple of (problem, class-alpha, class-dec, dateno1, cutter1,
#  dateno2, cutter2, misc) we stick all 'problem' callnos, like
#  'ACQUISITION IN PROGRESS' or 'yymm NOT YET IN LC' into the first
#  field, and consolidate the last 4 fields mentioned there into a single
#  'misc'.  I believe we could get the correct results by 0-padding the
#  class # on the left to 4 digits and then doing field-by-field
#  comparisons.  Not clear.  Both methods suffer from not correctly
#  sorting vol. # and pt. # indications (v.2 collates after v.10.)

#  It might well be better to stick this code inside the database, since
#  it needs to be sync'd among all users.  That would impede portability,
#  though.

#  We also need to keep the original class/item split, since that's not
#  reflected in this breakdown (and can only be recovered by reference to
#  the cataloging schedules...)  This code has been rather fragile.  Can
#  I do better? XXX

date = r'( \d\S*)?' # or other number, e.g. 15th
cut1 = r'( ?\.\S\d*)?'
cut2 = r'( ?\S\d*)?'
regex = r'([A-Z]{1,3})(?:(\d+(?:\.\d+)?)' + date + cut1 + \
        date + cut2 + '(.*))?'

#  XXX this accepts call nos like TX.S55 where decimal is missing but
#  rest is present.  Fix.  The reason for leniency is that this code is
#  also used by search parser, so we want to allow input of just a class.
#  Perhaps we should take a strictness flag to disambiguate the two uses?

robj = re.compile (regex)

# Note: sometimes first cutter is missing '.' as well: see AG195 A38 1994,
# _Return of the Straight Dope_.  Should we compensate?

def replace_none_strip(s):
    if type(s) == type(None):
        return ""
    else:
        return string.strip (s)

def parse (klass, item):
    call = klass + ' ' + item
    m = robj.match (call)
# avoid matching 'ACQUISITION IN PROGRESS' as class 'ACQ' ... misc
# field 'UISITION IN PROGRESS' while allowing 'TX' or 'DJK' to parse as
# just class
    if m == None or (m.groups ()[1] == None and
                     m.end (0) <> len(call) and len(call) > 3):
        return [replace_none_strip(call), "",0,"","","","",""]
    l = list(m.groups ())
    if l[1] == None:
        l[1] = '0'
    return [""] + map (replace_none_strip, l)

# sync field_names w/ create_lib.sql
field_names = ['problem', 'class_text', 'class_decimal', 'dateno1',
               'cutter1', 'dateno2', 'cutter2', 'misc'] 

if __name__ == '__main__':
    print "regex is", regex
    import util
    import pgdb
    libstring = util.get_libname ()
    print libstring
    conn = pgdb.connect(libstring)
    curs = conn.cursor ()
    curs.execute ('SELECT class,item FROM call_no ORDER BY class, item')
    res = curs.fetchall ()
    for call in res:
        p = parse(call[0], call[1])
        print call, p, len (p)
