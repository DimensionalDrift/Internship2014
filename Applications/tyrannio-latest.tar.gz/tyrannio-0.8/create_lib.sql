-- We have to specify NOT NULL for any item participating in a UNIQUE 
-- constraint, since PostGres, in a (deliberate) deviation from SQL92,
-- ignores uniqueness constraints when NULL is present.  (This makes
-- more sense when it's the only column.)

CREATE USER lucien;

CREATE SEQUENCE w_uncataloged;
-- sequence used to generate unique call #s beginning with W
-- as temporary callnos, when call # is not yet available.

CREATE TABLE main (
       seq SERIAL UNIQUE CONSTRAINT bibno_constr PRIMARY KEY, -- both needed?
       creation_date timestamp DEFAULT current_timestamp,
       src_accession_code TEXT NOT NULL, -- source of MARC 001
       src_accession_no TEXT NOT NULL, --  MARC 001
       lccn  TEXT UNIQUE, -- MARC 010, rely on PostGreSQL extension to allow UNIQUE 
-- cols to be NULL (if, say, we get records from NLC-BNC)
-- we ignore the possibility of both LC and NUCMC control #s, or
-- cancelled control #s, or $8 link fields
       edition_stmt_1 TEXT, --MARC 250
       edition_stmt_2 TEXT, -- freq. stmt of responsibility, ignore $6,$8
       shelving TEXT NOT NULL DEFAULT '' -- normalize XXX?
);

CREATE TABLE call_no (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       class TEXT DEFAULT '' NOT NULL,
       item  TEXT DEFAULT '' NOT NULL,
-- fields derived from class/item for correct collation:
-- If theoretical portability were unimportant, best to implement
-- callno as a new postgres type.  Alternately, implement these w/
-- a trigger to keep in sync w/ class, item.  Keep sync'd w/ call.py
       problem TEXT,
       class_text TEXT,
       class_decimal DECIMAL,
       dateno1 TEXT, -- used for, e.g. BX830.
       cutter1 TEXT,
       dateno2 TEXT,
       cutter2 TEXT,
       misc TEXT, -- date, vol or part indicators, work letters, shelving info e.g. "(Orien China)"
-- LC's location info we could probably do w/out
-- end derived fields
       ctr   INT4 NOT NULL-- for preference ordering of call #s
-- item specified as NR: alt. classes carry item # in $a field, or (more
-- often) not at all.
-- we could split W uncataloged across class and item, but why bother?
-- ignore $3, mat. specified, $8, link
--  CONSTRAINT callno UNIQUE (lccall_class, lccall_item)
-- frequently alt. call nos. are just a class, and until we
-- assign our own cutters, we can't apply this constraint.
-- Of course, issuing our own cutters compatibly with as-yet-LC-
-- unassigned cutters is, um, difficult
);

CREATE INDEX call_bib ON call_no (bibno);

-- pub_info not currently normalized.  Introduce pub_no_map?
-- note that these data are kinda dirty: e.g. places are
-- "Ithaca, N.Y." and "Ithaca, NY" for isbns 1563411024
-- and 1563411229.

CREATE TABLE pub_info (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       place TEXT DEFAULT '' NOT NULL, --MARC 260, lots of substructure
       name  TEXT DEFAULT '' NOT NULL,
       date  TEXT DEFAULT '' NOT NULL,
       mfg_place TEXT DEFAULT '' NOT NULL,
       mfg_name TEXT DEFAULT '' NOT NULL,
       mfg_date TEXT DEFAULT '' NOT NULL,
       ctr   INT4 NOT NULL
);

CREATE INDEX pub_bib ON pub_info(bibno);


-- we really need separate authority files for pers. names,
-- corp names, meeting names, and uncontrolled names, because of all
-- the differing substructure for each
CREATE TABLE auth_personal (
       seq  SERIAL UNIQUE CONSTRAINT authno_constr PRIMARY KEY,
       name   TEXT DEFAULT '' NOT NULL,
       dates  TEXT DEFAULT '' NOT NULL,
       numeration TEXT DEFAULT '' NOT NULL,
       title      TEXT DEFAULT '' NOT NULL,
       misc       TEXT DEFAULT '' NOT NULL,
       fuller_name TEXT DEFAULT '' NOT NULL,
       name_type CHAR(1) DEFAULT ' ' NOT NULL, -- MARC 100 1st indicator
       CONSTRAINT unique_nm UNIQUE (name, numeration, title, misc, dates, fuller_name)
);

CREATE TABLE auth_corp (
       seq SERIAL UNIQUE CONSTRAINT auth_corp_no_constr PRIMARY KEY,
       name_type CHAR(1) DEFAULT ' ' NOT NULL, -- MARC 100 1st indicator       
       corp_juris_name  TEXT DEFAULT '' NOT NULL,
       subord_unit TEXT DEFAULT '' NOT NULL,
       mtg_loc  TEXT DEFAULT '' NOT NULL,
       date  TEXT DEFAULT '' NOT NULL,
       misc TEXT DEFAULT '' NOT NULL,
       language TEXT DEFAULT '' NOT NULL, 
       number_part_section TEXT DEFAULT '' NOT NULL,
       name_part_section TEXT DEFAULT '' NOT NULL, 
       affiliation_address TEXT DEFAULT '' NOT NULL,
       CONSTRAINT unique_cjn UNIQUE (corp_juris_name, subord_unit, misc)
);

CREATE TABLE auth_mtg (
       seq SERIAL UNIQUE CONSTRAINT auth_mtg_no_constr PRIMARY KEY,
       name_or_juris_name TEXT DEFAULT '' NOT NULL,
       loc  TEXT DEFAULT '' NOT NULL,
       date  TEXT DEFAULT '' NOT NULL,
       subord_unit  TEXT DEFAULT '' NOT NULL,
       number TEXT DEFAULT '' NOT NULL,
       sub_name TEXT DEFAULT '' NOT NULL,
       CONSTRAINT unique_am UNIQUE (name_or_juris_name, loc, date,subord_unit, sub_name)
);
       
              

CREATE TABLE auth_personal_map (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       authno INT4 REFERENCES auth_personal (seq) MATCH FULL ON DELETE CASCADE,
       relator TEXT DEFAULT '' NOT NULL, -- $e
       CONSTRAINT unique_apm UNIQUE (bibno, authno, relator)
);

CREATE TABLE auth_corp_map (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       authno INT4 REFERENCES auth_corp (seq) MATCH FULL ON DELETE CASCADE,
       relator TEXT DEFAULT '' NOT NULL, -- $4
       CONSTRAINT unique_acm UNIQUE (bibno, authno, relator)
);

CREATE TABLE auth_mtg_map (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       authno INT4 REFERENCES auth_mtg (seq) MATCH FULL ON DELETE CASCADE,
       relator TEXT DEFAULT '' NOT NULL, -- $4
       CONSTRAINT unique_amm UNIQUE (bibno, authno, relator)
);

-- includes 240, 242, 245, 246, 247, 130, and maybe others.
-- Yuck.
-- DEFAULTs added b/c NULL concat x = NULL, and we concat frequently
CREATE TABLE title (
       bibno INT4 REFERENCES main (seq) MATCH FULL ON DELETE CASCADE,
       title_type TEXT DEFAULT '' NOT NULL,
       prefix TEXT DEFAULT '' NOT NULL,
       suffix TEXT  DEFAULT '' NOT NULL, 
-- collate on title suffix case-insensitively.  How? XXX
-- AACR2/ISBD doesn't capitalize subseq. words in title?
       subtitle TEXT  DEFAULT '' NOT NULL,
       resp_stmt TEXT  DEFAULT '' NOT NULL,
       language TEXT DEFAULT '' NOT NULL,
       date TEXT DEFAULT '' NOT NULL, -- may also be a range of dates
       form TEXT DEFAULT '' NOT NULL,
       medium TEXT DEFAULT '' NOT NULL,
       number TEXT DEFAULT '' NOT NULL,
       part TEXT DEFAULT '' NOT NULL,
       version TEXT DEFAULT '' NOT NULL,
       primary_flag bool,
       uniform_flag bool
);

CREATE INDEX title_bib on title (bibno);

CREATE TABLE subj (
       seq SERIAL UNIQUE CONSTRAINT seq_constr PRIMARY KEY,
       fieldno INT4,
       ind1  char(1),
       ind2  char(1),
       prefix TEXT DEFAULT '',
       subj TEXT DEFAULT '',
       source TEXT DEFAULT '', -- $2 field
       CONSTRAINT unique_subj UNIQUE (ind1, ind2, fieldno, prefix, subj, source)
       );

CREATE TABLE subj_map (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       subjno INT4 REFERENCES subj(seq) MATCH FULL ON DELETE CASCADE,
       CONSTRAINT unique_sm UNIQUE (bibno, subjno)
);

CREATE TABLE notes (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       field INT2, -- which of the 5XX fields this is
       ind1  char(1),
       ind2  char(1),
       note	  TEXT
);

CREATE INDEX notes_bib ON notes(bibno);

CREATE TABLE isbn (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       isbn  text DEFAULT '' NOT NULL, -- + parenthetical qualifier, if present
-- not specified as unique, because pubs can accidentally assign
-- the same ISBN to two books, and LC can fail to catch this: see
-- Orson Scott Card's _Ender's Game_ and _Xenocide_ for example.
-- I have the mass market edns instead of the trade ones cataloged
-- by LC, so I don't know who's to blame.
       fmt   text DEFAULT '' NOT NULL,
       ind1  char(1),
       ind2  char(1), -- XXX not actually defined for ISBN
       avail_terms text DEFAULT '' NOT NULL,
       valid bool, -- subfield was $a, not $z
       present bool -- I have this particular ISBN.  Why keep
-- other ISBNs?  I'm a packrat.
);

CREATE INDEX isbn_bib ON isbn(bibno);
CREATE TABLE isbn_present (
       present bool, 
       present_text text);

INSERT INTO isbn_present (present, present_text) VALUES (false, '(alternate edtn.)');
INSERT INTO isbn_present (present, present_text) VALUES (true, '');

CREATE TABLE isbn_valid (
       valid bool, 
       valid_text text);

INSERT INTO isbn_valid (valid, valid_text) VALUES (false, '(invalid)');
INSERT INTO isbn_valid (valid, valid_text) VALUES (true, '');


CREATE VIEW isbn_view AS SELECT isbn.*, isbn_present.present_text, isbn_valid.valid_text
FROM isbn, isbn_present, isbn_valid WHERE isbn.valid = isbn_valid.valid and isbn.present
= isbn_present.present; -- XXX better to handle isbn_view expansion in front end? 

CREATE TABLE phys_descr (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       ind1  char(1), -- XXX inds not used
       ind2  char(1),
       extent text   DEFAULT '' NOT NULL, 
       other_details  text   DEFAULT '' NOT NULL,
       dimensions  text   DEFAULT '' NOT NULL,
       accompanying  text   DEFAULT '' NOT NULL,
       unit_type  text   DEFAULT '' NOT NULL,
       unit_size  text  DEFAULT '' NOT NULL ,
       mat_specified  text   DEFAULT '' NOT NULL,
       preface_pages  INT4 DEFAULT 0 NOT NULL,
       main_pages     INT4 DEFAULT 0 NOT NULL,
       ctr	      INT4 NOT NULL
);

CREATE INDEX phys_bib ON phys_descr (bibno);

-- whatever fields aren't explicitly handled.  More for debugging,
-- and investigation than for use.
CREATE TABLE misc (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       field INT2,
       ind1  char(1),
       ind2  char(1),
       data  TEXT
);

CREATE TABLE series (
       seq SERIAL UNIQUE CONSTRAINT series_constr PRIMARY KEY,
       prefix TEXT DEFAULT '' NOT NULL,
       suffix TEXT DEFAULT '' NOT NULL,
       subtitle TEXT DEFAULT '' NOT NULL, -- actually the title part of an 8[01][11] field
       part_no TEXT DEFAULT '' NOT NULL,
       part_name TEXT DEFAULT '' NOT NULL,
       issn TEXT DEFAULT '' NOT NULL,
       lc_call TEXT DEFAULT '' NOT NULL,
       primary_flag boolean DEFAULT TRUE NOT NULL, -- XXX remove these two from series
       uniform_flag boolean DEFAULT FALSE NOT NULL,
       CONSTRAINT unique_series UNIQUE(prefix,suffix,subtitle,primary_flag, uniform_flag, part_no, part_name, issn, lc_call)
);

CREATE TABLE series_map (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       seriesno INT4 REFERENCES series(seq) MATCH FULL ON DELETE CASCADE,
       vol TEXT DEFAULT '' NOT NULL,
       primary_flag boolean
-- XXX uniqueness constraint needed?
);

CREATE TABLE electronic_link (
       bibno INT4 REFERENCES main(seq) MATCH FULL ON DELETE CASCADE,
       urn TEXT default '' NOT NULL,
       url TEXT default '' NOT NULL,
       note TEXT default '' NOT NULL,
       mat_specified TEXT default '' NOT NULL
);       

CREATE INDEX el_bib ON electronic_link (bibno);

GRANT SELECT ON main TO lucien;
GRANT SELECT ON call_no TO lucien;
GRANT SELECT ON pub_info TO lucien;
GRANT SELECT ON auth_personal TO lucien;
GRANT SELECT ON auth_corp TO lucien;
GRANT SELECT ON auth_mtg TO lucien;
GRANT SELECT ON auth_personal_map TO lucien;
GRANT SELECT ON auth_corp_map TO lucien;
GRANT SELECT ON auth_mtg_map TO lucien;
GRANT SELECT ON title TO lucien;
GRANT SELECT ON subj TO lucien;
GRANT SELECT ON subj_map TO lucien;
GRANT SELECT ON notes TO lucien;
GRANT SELECT ON isbn_view TO lucien;
GRANT SELECT ON phys_descr TO lucien;
GRANT SELECT ON misc TO lucien;
GRANT SELECT ON series TO lucien;
GRANT SELECT ON series_map TO lucien;
GRANT SELECT ON electronic_link TO lucien;













