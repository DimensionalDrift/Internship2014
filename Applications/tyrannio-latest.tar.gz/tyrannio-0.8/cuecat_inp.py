#!/usr/bin/env python

# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.


import base64
import string

# decode is only publicly usable function: it takes a line of
# raw cuecat input, and returns a (type, data) tuple, where
# the type values of interest are "IBN" for Bookland and
# "IB5" for Bookland + 5 (with prices).


def swap_ul(c):
    if c in string.lowercase:
        c = string.upper (c)
    else:
        if c in string.uppercase:
            c = string.lower(c)
    return c

def decode_char(c):
    return chr (ord(c) ^ ord('C')) #0x43

def decode_string(s):
    s = string.join(map(swap_ul, s))
    return string.join(map(decode_char,base64.decodestring(s)),"")

def decode (raw):        
    slist = string.split (raw, ".")
    typ = decode_string(slist[2])
    l = len(slist[3])
    excess_len = l - (l/4) * 4
    if excess_len <> 0:
        pad_len = 4 - excess_len
    else:
        pad_len = 0
    data = slist [3] + ('=' * pad_len)
    data = decode_string (data)
    return (typ,data)

if __name__ == '__main__':
    while 1:
        raw = raw_input ("")
        if len(raw) == 0:
            break
        print decode (raw)

    
