#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import sys
import urllib
import htmllib
import formatter
from cStringIO import StringIO
import urlparse
import re
import string
import md5

# Parts stolen from Aahz's threading tutorial, see http://www.rahul.net/~aahz
# even though code is not yet threaded.

def extract_refs (html):
    w = formatter.DumbWriter(StringIO())
    f = formatter.AbstractFormatter(w)
    parser = htmllib.HTMLParser(f)
    parser.feed(html)
    alist = parser.anchorlist
    parser.close()
    return alist


# is this unquote really not available in the std. library?
def unquote (u): 
    return re.sub ('&lt;', '<', re.sub ('&gt;','>', re.sub ('&amp;', '&', u)))

def canon (base, url):
    return urlparse.urljoin (base, unquote (url))

class Url:
    ctr = 0
    def __init__ (self, url, initloc):
        self.dup = 0
        f = urllib.urlopen (url)
        self.data = f.read ()
        f.close ()
        refs = extract_refs (self.data)
        self.refs = []
        self.full_refs = []
        for ref in refs:
            full_ref = canon (url, ref)
            tpl = urlparse.urlparse (full_ref)
# avoid following external references.  This is not quite right,
# since URLs can differ in netloc without referring to different machines
# (e.g. if one specifies port 80 explicitly and the other defaults it.)
            if tpl[1] == initloc:
                self.refs.append (ref)
                self.full_refs.append (full_ref)
        self.ctr = Url.ctr
        Url.ctr = Url.ctr + 1
    def set_ctr (self, new_ctr):
        self.dup = 1
        self.ctr = new_ctr
        
class DeDyn:
    def __init__ (self, init_url, depth):
        self.init_url = init_url
        init_loc = urlparse.urlparse (init_url)[1]
        to_get = [(self.init_url, depth)]
        dup = 0
        self.urls = {}
        self.md5s = {}
# This is the wrong level at which to implement the md5 code.  Url could
# implement an abstraction which transparently makes urls with the same data
# (and same prefix -> same interpretation of relative URLs) map to the same
# ctr.
        while len (to_get) > 0:
            (url, depth) = to_get[-1]
            to_get = to_get[:-1]
            if self.urls.get (url) == None:
                print "Queue len: ", len (to_get), "So far: ", Url.ctr,\
                      "Dups: ", dup," Url:", url
                urlobj = Url (url, init_loc)
                self.urls[url] = urlobj
                md5h = md5.new(urlobj.data).digest ()
                md5d = self.md5s.get (md5h)
                if md5d <> None:
                    old_ctr = self.urls[md5d].ctr
                    print "Dup: resetting ctr ", urlobj.ctr, old_ctr
                    dup = dup + 1 # and reset ctr to other, skip next code?
                    if self.urls[md5d].data <> urlobj.data:
                        print "MD5 collision!"
                        sys.exit (255)
                    urlobj.set_ctr (old_ctr)
                else: self.md5s[md5h] = url
                if depth > 0:
                    for e in urlobj.full_refs:
                        if not self.urls.has_key (e):
                            to_get.append ((e, depth-1))
                            self.urls[e] = None
                    
# I wanted to use the original url parms as part of the file name, but
# they can be longer than the maximum file length.  I suppose I could truncate.
    def mk_filename (self, u, ctr):
        tpl = urlparse.urlparse (u)
# XXX different netloc can be same URL (e.g. if specify port 80 vs. not)
        path = tpl [2]
        i = string.rfind (path, '/')
        if i <> -1:
            path = path [i+1:]
        fn =  path + str (ctr) + ".html"
        return fn

    def quote (self, s):
        return '"%s"' % s 
    def write (self):
        for u in self.urls.keys ():
            print "Key: ", u
            uobj = self.urls [u]
            if uobj.dup:
                print "Skipping, dup"
                continue
            to_write = uobj.data
            nm = self.mk_filename (u, uobj.ctr)
            for ref in uobj.refs:
                full_ref = canon (u, ref)
                sorry = 0
                if self.urls.has_key (full_ref):
                    new_ref = self.mk_filename (ref, self.urls[full_ref].ctr)
                else:
                    sorry = 1
                    new_ref = "sorry.html"
# need to quote b/c one url can be strict prefix of another.  If I were less
# lazy, I'd parse the HTML, frob the As (testing for equality), and write
# it back out, but regexes work.
                to_write = re.sub (re.escape (self.quote(ref)),
                                   self.quote(new_ref), to_write)
                if sorry:
                    print "Sorry", u, nm, "Refs", ref, full_ref, new_ref
            f = open (nm, "w")
            f.write (to_write)
            f.close ()
        
if __name__ == '__main__':
    DeDyn(sys.argv[2],string.atoi(sys.argv[1])).write ()

