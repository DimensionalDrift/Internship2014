#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2002 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.



import lucien
import merv
from PyZ3950 import zoom, zmarc
import ext_conf

max_disp = 25

# Blech.  I can't rely on anything in particular to link a MARC record
# to something I can query on for the full display.  In particular,
# for Oxford and Yale, the contents of MARC field 1 don't seem to be
# usable by a query for BIB-1 use-attribute 12, despite the suggestion
# at ftp://ftp.loc.gov/pub/z3950/defs/bib1.txt.  LCCNs and ISBNs are
# neither guaranteed to exist nor to be unique.

tbl_to_ccl_qual = [
    'TI',
    '(1,1)',
    '(1,2)',
    '(1,3)',
    '(1,16)', # call #
    '(1,5)', # series
    '(1,21)', # subject, or is that 27? 
    '(1,108)', # publisher
    None, # phys descr
    None, # Notes,
    'ISBN',
    'LCCN',
    None] # Electronic link
    

fmt = merv.Formatter ()
pe  = merv.ParmExtracter ()
pe.req_parm ('table', 'd')
pe.req_parm ('key', 's')
pe.opt_parm ('start', 'd', 0)

def get (table, key, start):
    qual = tbl_to_ccl_qual [table]
    if qual == None:
        return [(None, str (table) + ' Not supported')]
    # XXX really should have this be settable via parm.
    (host, port, db) = ext_conf.get_db ()
    conn = zoom.Connection (host, port)
    conn.preferredRecordSyntax = 'USMARC'
    conn.databaseName = db
    if table == 6:
        qual += ",(3,1),(5,1)" # position, truncation
        # see http://lcweb.loc.gov/z3950/lcserver.html
    if table == 0:
        ind = key.find ('/')
        if ind <> -1:
            key = key [:ind-1]
        ind = key.find (':')
        if ind == -1:
            cclq = '%s="%s"' % (qual, key)
        else:
            cclq = '%s="%s" and %s="%s"' % (qual, key[0:ind],
                                            qual, key[ind+1:])
    elif table <> 4:
            cclq = '%s="%s"' % (qual, key)
    else:
        # ugh.  LC doesn't currently search across subfield bdaries for
        # 050 $a $b, so we have to split manually and stuff.
        ind = key.find (' ')
        if ind == -1:
            cclq = '%s="%s"' % (qual, key)
        else:
            cclq = '%s="%s" and %s="%s"' % (qual, key[0:ind],
                                            qual, key[ind+1:])
    try:
        q = zoom.Query ('CCL', cclq)
        res = conn.search (q)
        l = []
        for r in res[start: start + max_disp]:
            if r.syntax <> 'USMARC':
                l.append ((None, 'Bad syntax: ' + r.syntax, None))
            else:
                m = zmarc.MARC (r.data)
                lcid = m.fields[1][0]
                title = " ".join ([v[1] for v in m.fields [245][0][2]])
                l.append ((lcid, title, r.data))
        conn.close ()
        return (len (res), l)
    except zoom.ZoomError, err:
        fmt.para_begin ()
        fmt.emit_text ('Zoom error: %s for query %s' %
                       (str(err), cclq))
        return None


import base64

if __name__ == '__main__':
    if not pe.parse ():
        fmt.form_error ()
    else:
        fmt.page_begin ('LC Browse')
        start = pe['start']
        r = get (pe['table'], pe['key'], start)
        if r <> None:
            (mylen, recs) = r
            fmt.para_begin ()
            def elt (f, i, e):
                (lcid, title, marc) = e
                f.emit_link (title, 'ext_full.py',
                             data=base64.encodestring (marc))
#                f.emit_link (title, 'lcfull.py', lcid=lcid)
            fmt.list_emit (elt, recs)
            if mylen > start + len (recs):
                fmt.emit_link ('Next', 'lcbrowse.py', table = pe['table'],
                               key = pe['key'], start = start + len (recs))
            fmt.para_begin ()
            fmt.emit_text ('Total records: ' + str (mylen))
        fmt.page_end ()
            
        
        
