def get_db ():
    return ('z3950.loc.gov', 7090, 'VOYAGER')

#  def get_db ():
#      return (
#          'library.ox.ac.uk',
#          210,
#          'ADVANCE')

#  def get_db ():
#      return (
#          'webpac.library.yale.edu',
#          210,
#          'YALEOPAC')

