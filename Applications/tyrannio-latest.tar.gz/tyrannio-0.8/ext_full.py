#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2002 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

from __future__ import nested_scopes

import lucien
import merv
from PyZ3950 import zmarc
import base64

fmt = merv.Formatter ()
pe  = merv.ParmExtracter ()
pe.req_parm ('data', 's')

if __name__ == '__main__':
    if not pe.parse ():
        fmt.form_error ()
    else:
        fmt.page_begin ('External full')
        fmt.para_begin ()
        marc = base64.decodestring (pe['data'])
        text = str (zmarc.MARC (marc))
        for l in text.split ('\n'):
            fmt.emit_text (l)
            fmt.line_end ()
        fmt.page_end ()
            
        
        
