#!/usr/bin/env python

# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import lucien
import merv

def run (fmt, bibno, dbg = 0, ext = 0):
    fmt.page_begin ('Full Display')
    fmt.para_begin ()
    fmt.heading (1, 'Full Display:')
    q = lucien.query (merv.make_dbg (fmt, dbg))
    final_queries = lucien.mk_full_query (bibno)
    table = 0 # XXX 
    for pretty_name, query, is_mapped in final_queries:
        if query <> None:
            res = q.run (query)
            if len(res) > 0:
                fmt.para_begin ()
                fmt.emit_text (pretty_name + ':')
                fmt.para_end ()
                fmt.para_begin ()
                for e in res:
                    if is_mapped:
                        (seq, f, relator, cnt) = e
                        if cnt > 1:
                            fmt.emit_link (f + relator, 'map_q.py',
                                           table=table, seq=seq)
                        else:
                            fmt.emit_link (f + relator, 'full.py',
                                           bibno=bibno) # or...
                            
#                           fmt.emit_text (f + relator)
# I like the look of the redundant link somewhat better.  If we didn't
# test cnt > 1, for works w/ alternate titles, map_q would display them.

                        fmt.emit_link ('(browse)', 'query.py',
                                       table=table, key=f)
                        fmt.emit_text ('(%d)' % cnt)
                        if ext:
                            fmt.emit_link ('(external browse)',
                                           'ext_browse.py',
                                           table=table, key=f)
                    else:
                        if lucien.tables[table].table == 'electronic_link':
                            fmt.emit_link (e[0], e[1])
                        else:
                            if e[1] == None: e[1] = ''
                            # XXX kinda hackish, and produces empty link
                            fmt.emit_link (e[0] + e[1], 'query.py',
                                           table=table, key=e[1],
                                           bibno=bibno)
                            if ext:
                                fmt.emit_link ('(external browse)',
                                               'ext_browse.py',
                                               table=table, key=e[1])

                    fmt.line_end ()
        table = table + 1

    fmt.page_end ()

if __name__ == '__main__':
    fmt = merv.Formatter ()
    pe = merv.ParmExtracter ()
    pe.req_parm ('bibno', 'd')
    pe.opt_parm ('dbg', 'b', 0)
    pe.opt_parm ('ext', 'b', 0)
    if not pe.parse ():
        fmt.form_error ()
    else:
        run (fmt, pe['bibno'], pe['dbg'], pe['ext'])


                        






