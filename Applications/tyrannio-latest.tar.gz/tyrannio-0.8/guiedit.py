#!/usr/bin/env python

from __future__ import nested_scopes

import gtk

from PyZ3950 import zoom, zmarc

import marcwidget
import tyrannio

class DataError (Exception): pass

# check 800 searchable as by author
# spaces on either side of subfield
# think about authority control
# cosmetic stuff
# where have all the 7s gone?
# finish editing code -- extract from MarcWidget to zmarc
#                     -- add adding/deleting subfields, fields
# make default column widths better

conninfo = {
    'NLC'   : ('amicus.nlc-bnc.ca', 210, 'NL'),
#    'BL'    : ('blpcz.bl.uk', 21021, 'BLPC-ALL'),
# Not until we xlate GRS-1 -> MARC: http://www.bl.uk/catalogues/blpczfull.html
    'LC'    : ('z3950.loc.gov', 7090, 'VOYAGER'),
    'LOCAL' : ('localhost', 9999, 'Default')
    }

class MultiConn:
    def __init__ (self, syntax):
        self.syntax = syntax
        self.cur_target = 'LC'
        self.conns = {}
        menu = gtk.GtkMenu ()
        ck = conninfo.keys ()
        for key in ck:
            item = gtk.GtkMenuItem (key)
            item.show ()
            def activate (it, key = key):
                self.cur_target = key
            item.connect ('activate', activate)
            menu.append (item)
        menu.set_active (ck.index (self.cur_target))
        self.optionmenu = gtk.GtkOptionMenu ()
        self.optionmenu.set_menu (menu)
        self.optionmenu.show ()
        
    def search (self, cclquery):
        q = zoom.Query ('CCL', cclquery)
        if self.conns.get (self.cur_target) == None:
            (host, port, db) = conninfo [self.cur_target]
            self.conns [self.cur_target] = zoom.Connection (host, port)
            self.conns [self.cur_target].databaseName = db
        return self.conns [self.cur_target].search (q)

        
        
class App:
    def __init__ (self):
        self.cols = [(245, 'Title'), (100, 'Author'), (20, 'ISBN'),
                     (250, 'Edition'), (260, 'Publisher'),
                     (300, 'Physical description')]
        self.multiconn = MultiConn (syntax = 'USMARC')
        self.wnd = self.mk_wnd ()

        self.db_conn = tyrannio.get_conn ()
        self.max_records = 40
    def mk_wnd (self):
        def box_add (title, obj, scroll = 0, expand = 1):
            frame = gtk.GtkFrame (title)
            obj.show ()
            frame.show ()
            if scroll:
                s = gtk.GtkScrolledWindow ()
                s.add (obj)
                s.show ()
                frame.add (s)
            else:
                frame.add (obj)
            self.box.pack_start (frame, expand = expand)
            return obj
        self.box = gtk.GtkVBox ()
        hbox = gtk.GtkHBox ()
        hbox.pack_start (self.multiconn.optionmenu)
        self.query_entry = gtk.GtkEntry ()
        self.query_entry.show ()
        hbox.pack_start (self.query_entry, expand = 1)
        self.lookup_but = gtk.GtkButton ('Lookup')
        self.lookup_but.show ()
        hbox.pack_start (self.lookup_but, expand = 0)
        self.more_but   = gtk.GtkButton ('Retrieve More')
        self.more_but.show ()
        self.more_but.set_sensitive (0)
        hbox.pack_start (self.more_but, expand = 0)
        box_add ('Query:', hbox, expand = 0)
        title_strs = [c[1] for c in self.cols] + ['Index']
        self.titles_lb = box_add ('Titles:', gtk.GtkCList (len (title_strs),
                                                           title_strs),
                                  scroll = 1)
        self.titles_lb.set_usize (300, 300) # Ugh XXX
        self.marc_wdg   = box_add ('Data for title:',
                                   marcwidget.MarcWidget ())
        self.import_but = box_add ('Import: ', gtk.GtkButton ('Import'))
        self.status_lab= box_add ('Status:', gtk.GtkLabel (), expand = 0)
        self.lookup_but.connect ('clicked', lambda but: self.send_query ())
        self.more_but.connect ('clicked', lambda but: self.retrieve_more ())
        self.titles_lb.connect ('select-row',
                                lambda lb, row, col, ev: self.sel_title (row))
        self.titles_lb.column_titles_active ()
        def col_clicked (lb, col):
            print lb, col, self.titles_lb
            lb.set_sort_column (col)
            lb.sort () # XXX or set auto-sort?
        self.titles_lb.connect ('click-column', col_clicked)
        self.titles_lb.set_sort_column (0) # XXX make preference
        self.import_but.connect ('clicked', lambda but: self.import_marc ())
        wnd = gtk.GtkWindow ()
        wnd.add (self.box)
        self.box.show ()
        wnd.show ()
        return wnd
    def process_recs (self, beg, end):
        def extract_dat (r):
            if r == None:
                return None
            if r.syntax <> 'USMARC':
                raise DataError ('Bad syntax ' + r.syntax)
            m = zmarc.MARC (r.data)
            l = []
            for i in range (len (self.cols)):
                col = self.cols[i][0]
                t = []
                try:
                    for u in m.fields [col]:
                        t += u[2]
                except KeyError:
                    pass
                str = " ".join (map (lambda tup: tup [1], t))
                l.append (str)
            return l
        try:
            strlist = map (extract_dat, self.cur_res[beg:end])
        except zoom.ZoomError, z:
            self.set_status (str (z))
            return
        for i in range (len (strlist)):
            if strlist [i] == None:
                continue
            strlist[i].append ('%d' % (i + self.cur_end))
            self.titles_lb.append (strlist[i])
        self.more_but.set_sensitive (len (self.cur_res) > end)
        self.set_status ('%d items (%d displayed)' %
                         (len (self.cur_res), min (len (self.cur_res),end)))
        self.cur_end = end
    def send_query (self):
        try:
            self.cur_res = self.multiconn.search (self.query_entry.get_text ())
        except zoom.ZoomError, z:
            self.set_status (str (z))
            return
        self.titles_lb.clear ()
        self.marc_wdg.clear ()
        self.cur_end = 0
        self.process_recs (0, self.max_records)
        if len (self.cur_res) > 0:
            self.titles_lb.select_row (0, 0)
    def retrieve_more (self):
        self.process_recs (self.cur_end,
                           min (self.cur_end + self.max_records,
                                len (self.cur_res)))
    def sel_title (self, row):
        t = self.titles_lb.get_text (row, len (self.cols))
        self.cur_sel = int (t)
        self.marc_wdg.set_marc (self.cur_res [self.cur_sel].data)
    def set_status (self, text):
        self.status_lab.set_text (text)
    def import_marc (self):
        marc = self.marc_wdg.get_MARC ()
        print repr (marc)
        f = open ('badmarc', 'w')
        f.write (marc)
        f.close ()
        tyrannio.MARC_to_SQL (zmarc.MARC(marc), 
                         self.db_conn,
                         None, # ISBN
                         self.multiconn.cur_target.lower ())
    def run (self):
        gtk.mainloop ()

if __name__ == '__main__':
    App().run ()
