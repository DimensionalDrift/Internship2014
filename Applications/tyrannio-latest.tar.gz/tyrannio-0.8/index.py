#!/usr/bin/env python

# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import lucien
import merv

# This code used to be implemented as a server-side include, but a pure python
# implementation is a little easier to install.

fmt = merv.Formatter ()
fmt.page_begin ("Lucien Search")


fmt.emit_raw ("""<form method="get" action="query.py">
<p>Search By:
<select name="table">""")

table_list = lucien.get_table_name_list (lucien.tables)
for i in range (len(table_list)):
    fmt.emit_raw ('<option value=%d>%s' % (i, table_list[i]))

fmt.emit_raw ("""
</select>
<input type="text" name="key">
<input type=submit value="Search">
<p>
Number of items:
<input type="text" name="limit" value="20">
Wildcard: <input type="checkbox" name="wcinit">
<input type="hidden" name="init" value="1">
</form>
""")
fmt.page_end ()
