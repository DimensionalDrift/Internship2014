#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import sys
import pgdb
import string
import call
import util

# Controls which tables are queried and how: tuple of tuples.
# Tuple contains: pretty name, table name, nonsort-disp cols, sort cols, None | map col name
# (The map table name is always the original table name + '_map')
# table_init should either be stored in the db, or generated programmatically (from the
# same tables used on the input end, slightly augmented)

table_init = (
    ('Title', 'title', ['title_type', 'prefix'],
     ['suffix', 'subtitle','resp_stmt','language', 'date',
      'form', 'number', 'part',
      'version', 'medium'], None),
    ('Author (personal)', 'auth_personal', [],
     ['name','fuller_name', 'dates','numeration','title','misc'],
     ('authno', 'relator')),
    ('Author (corporate)', 'auth_corp', [],
     ['corp_juris_name','subord_unit','mtg_loc',
      'date','misc','language','number_part_section',
      'name_part_section','affiliation_address'],
     ('authno', 'relator')),
    ('Author (meeting)', 'auth_mtg', [],
     ['name_or_juris_name','number', 'date','loc',
      'subord_unit', 'sub_name'], ('authno', 'relator')),
    ('Call number', 'call_no', [], ['class',"' '", 'item'], None),
    ('Series', 'series', ['prefix'], ['suffix','subtitle','part_no',
                                      'part_name'], ('seriesno','vol')),
    ('Subject', 'subj', ['prefix'], ['subj', 'source'],('subjno', None)),
    ('Publisher', 'pub_info', ['place'], ['name', 'date'], None),
    ('Physical Description', 'phys_descr', [],
     ['extent','other_details','dimensions',
      'accompanying','unit_type','unit_size', 'mat_specified'], None),
    ('Notes', 'notes', [], ['note'], None),
    ('ISBN', 'isbn_view', [],
     ['isbn','fmt', 'avail_terms', 'present_text', 'valid_text'], None),
    ('LCCN', 'main', [], ['lccn'], None),
    ('Electronic link', 'electronic_link',
     ['mat_specified', 'note'], ['url'], None)
    )

import phys_descr


def call_parse_shim (s):
    return call.parse (s, '')

ctr_needed = ['call_no', 'pub_info', 'phys_descr']
search_by_fields = {'call_no': (call_parse_shim, call.field_names),
                    'phys_descr': (phys_descr.parse, phys_descr.field_names)}

def join_list (vals, sep):
    s = ""
    l = len (vals)
    for i in range(l):
        s = s + vals[i]
        if (i <> l - 1):
            s = s + sep
    return s

# maybe we should only prefix table name when really needed, making
# generated sql easier to read.
        
def pref (tbl, cols):
    def pref_one (col, tbl = tbl):
        if col == "' '": return col
        else: return tbl + '.' + col
    return map (pref_one, cols)

class SearchType:
    def __init__ (self, limit = 20, ascend = 1, eqtest = 1,
                  wildcard = '', bibno = 0):
        self.limit = limit
        self.ascend = ascend
        self.eqtest = eqtest
        self.wildcard = wildcard
        self.bibno = bibno # bibno from which to start, or 0 for none
    def make_relop (self, eqflag = 1):
        if self.ascend:
            relop = '>'
        else:
            relop = '<'
        if self.eqtest and eqflag:
            relop = relop + '='
        return relop
    def make_key (self, key):
        return util.quote_str (key)
    def make_wc_clause (self, col):
        if self.wildcard == '':
            return ''
        else:
            return "AND %s ~* '%s'" % (col, self.wildcard)
    def make_order_lim (self, collist, tbl, uniquifycol, concat_fields = 1):
        if self.ascend:
            dir = ''
        else:
            dir = ' DESC '
        if concat_fields:
            cols = string.join (pref (tbl, collist), '||')
            o = "ORDER BY upper(%s)" % cols
        else:
            o =  "ORDER BY %s" % join_list (collist, dir + ',')
        return o +  "%s, %s %s LIMIT %d" % (dir, uniquifycol, dir, self.limit)


libspec = util.get_libname ("lucien")

class Table:
    def __init__ (self, tpl):
        self.pretty_name, self.table, self.nonsort_cols_list, \
                          self.sort_cols_list, map_tpl = tpl
        self.nonsort_cols = string.join (
            pref (self.table, self.nonsort_cols_list), '||')
        self.sort_cols = string.join (
            pref (self.table, self.sort_cols_list), '||')
        self.ctr_needed =  self.table in ctr_needed
            
        if map_tpl <> None:
            if len (map_tpl) == 1:
                self.map_col = map_tpl
            else:
                self.map_col, self.relator_col = map_tpl
            self.map_tbl = self.table + "_map"
        else:
            self.map_col = None
        if self.table == 'main':
            self.bib_col = 'seq'
        else:
            self.bib_col = 'bibno'
            
        self.concat_fields =  not search_by_fields.has_key (self.table)
        if self.concat_fields:
            self.order_cols = self.sort_cols_list           
        else:
            self.order_cols = search_by_fields[self.table][1]

        
    def _all_cols(self):
        cols = self.nonsort_cols_list + self.sort_cols_list
        return string.join (cols, '||')
    
    def _mk_cols (self):
        ns = self.nonsort_cols
        if ns == '':
            ns = "''"
        return ns + ' AS nonfile, ' + self.sort_cols

    def _mk_bibno_clause (s, sopt):
        return "%s.%s %s %d" % (
            s.table, s.bib_col, sopt.make_relop (1), sopt.bibno)

    def _mk_FROM_WHERE (s, key, sopt, tables_extra = []):
        tables = [s.table] + tables_extra
        
        q = "FROM " + join_list (tables, ',') + " WHERE "
        if not s.concat_fields and not sopt.wildcard:
            parsefn, field_names = search_by_fields[s.table]
            pkey = parsefn (key)
            qkey = util.quote_list (pkey)
            fields = pref (s.table, field_names)
            wh = ''
            oldeq = sopt.eqtest
            sopt.eqtest = 0 # XXX yuck!!!
            eq_so_far = ''
            r = range(len(qkey))
            for i in r:
##              print "<p>", i, r, wh, eq_so_far
                if i <> 0: # and sopt.bibno > 0:
                    wh = wh + " AND "
                eq_so_far = eq_so_far + "%s = %s" % (fields[i], qkey[i])
                if i == r[-1]  and sopt.bibno > 0:
                    sopt.eqtest = oldeq
                    eq_so_far = eq_so_far + " AND " + s._mk_bibno_clause (sopt)
                    sopt.eqtest = 0
                wh = wh + "%s %s %s) or (%s " % (fields[i], sopt.make_relop (),
                                                         qkey[i], eq_so_far)
                eq_so_far = eq_so_far + " AND " 
            wh = '((' + wh + '))'
        else:
            skey = sopt.make_key (key)
            if sopt.bibno > 0 and s.map_col == None:
                wh = "(upper(%s) %s upper(%s) OR " % (
                    s.sort_cols, sopt.make_relop (0), skey)
                wh = wh + "(upper(%s) = upper(%s) AND %s))" % (
                    s.sort_cols, skey, s._mk_bibno_clause (sopt))
            else:
                wh = "upper(%s) %s upper(%s)" % (
                    s.sort_cols, sopt.make_relop (1), skey)
            wh = wh + sopt.make_wc_clause (s.sort_cols)
        return q + wh
            
    def _mk_ORDER_LIMIT (s, sopt):
        if s.map_col <> None:
            uniquifycol = 'seq'
        else:
            uniquifycol = s.bib_col
        uniquifycol = s.table + '.' + uniquifycol
        return sopt.make_order_lim (
            s.order_cols, s.table, uniquifycol, s.concat_fields)

    def init_nonmapped_query (s, key, sopt):
        cols = s._mk_cols ()
        where_extra = ''
        from_extra = []
        if s <> tables [0]:
            cols = cols  + ", ' ' || "  + tables[0].nonsort_cols + \
                   '||' + tables[0].sort_cols
            where_extra = where_extra + ' AND title.bibno = %s.%s' % (
                s.table, s.bib_col)
            where_extra = where_extra + ' AND title.primary_flag '
            from_extra = from_extra + [tables[0].table]
        if s <> tables [4]:
            cols = cols  + ", ' ' || "  + tables[4].sort_cols
            where_extra = where_extra + ' AND call_no.bibno = %s.%s ' % (
                s.table, s.bib_col)
            where_extra = where_extra + ' AND call_no.ctr = 0 ' 
            from_extra = from_extra + [tables[4].table]

        q = 'SELECT %s.%s AS key, %s  %s %s  %s' % (
            s.table, s.bib_col, cols, s._mk_FROM_WHERE (key, sopt, from_extra),
            where_extra, s._mk_ORDER_LIMIT (sopt))
        return q
    def init_mapped_query (s, key, sopt):
        if s.nonsort_cols <> '':
            grp = 'GROUP BY 1,2,3'
        else:
            grp = 'GROUP BY 1,3'
        q = ('SELECT seq AS mapped_key, %s, count(%s.bibno) AS count %s AND '
             'seq = %s_map.%s %s %s') % (
            s._mk_cols(), s.map_tbl, s._mk_FROM_WHERE(key, sopt, [s.map_tbl]),
            s.table, s.map_col, grp, s._mk_ORDER_LIMIT(sopt))
        return q
    def init_query (s, key, sopt):
        if s.map_col == None:
            f = s.init_nonmapped_query
        else:
            f = s.init_mapped_query
        return f (key, sopt)
    def _mk_relq (s):
        if s.relator_col <> None:
            relq = ", ' ' || %s.%s" % (s.map_tbl, s.relator_col)
        else:
            relq = ",  ' '"
        return relq
    def intermed_query (s, seq):
        clist = []
        whlist =  []
        frlist = []
        for t in (tables[0], tables[4]):
            clist = clist + [t._mk_cols ()]
            whlist = whlist + ['%s.bibno = %s.bibno' % (t.table, s.map_tbl)]
            if t.table == 'call_no': # XXX generify
                whlist = whlist + ['call_no.ctr = 0']
            frlist = frlist + [t.table]
        frlist = frlist + [s.map_tbl]
        cols = string.join (clist, ' || ') + s._mk_relq ()
        wh = string.join (whlist, ' AND ')
        fr = string.join (frlist, ',')
        q = ('SELECT title.bibno, ' + cols + ' FROM ' + fr + ' WHERE ' + wh
             + (' AND %s.%s = %d' % (s.map_tbl, s.map_col, seq)))
        return q + ' ORDER BY upper(%s)' % tables[0].sort_cols
    # XXX or if it's series, order by series_map.vol?
    def final_query (s, bibno):
        cols = s._all_cols ()
        if s.map_col == None:
            order = ''
            if s.ctr_needed:
                order = ' ORDER BY ctr'
                # not enough to make, e.g., notes stable, but not really nec.
            return 'SELECT %s FROM %s WHERE %s = %d %s' % (
                s._mk_cols (), s.table, s.bib_col, bibno, order)
        else:
            relq = s._mk_relq ()
            if s.relator_col <> None:
                group_extra = ',3'
            else: group_extra = ''
            return 'SELECT seq, %s.%s %s, COUNT(%s_2.bibno) FROM %s, %s, %s %s_2 WHERE %s.seq = %s.%s AND %s.bibno = %d AND %s_2.%s = seq  GROUP BY 1,2 %s ORDER BY 2' % (
                s.table, cols, relq, s.map_tbl, s.table, s.map_tbl,
                s.map_tbl, s.map_tbl, s.table, s.map_tbl, s.map_col,
                s.map_tbl, bibno, s.map_tbl, s.map_col, group_extra)
    def bib_query (s, seq):
        return 'SELECT bibno FROM %s WHERE %s = %d' % (
            s.map_tbl, s.map_col, seq)

tables = map (Table, table_init)

def get_table_name_list(tables):
    return map (lambda t: t.pretty_name, tables)

def is_mapped (i):
    return tables[i].map_col <> None

def mk_init_query (i, key, limit, reverse, wcpattern, bibno = 0):
    t = tables [i]
    sopt = SearchType (limit, not reverse, 1, wcpattern, bibno)
    return t.init_query (key, sopt)

def mk_intermed_query (i, seq):
    return tables[i].intermed_query (seq)

def mk_full_query (bibno):
    q_l = []
    for t in tables:
        q_l.append ((t.pretty_name, t.final_query (bibno), t.map_col <> None))
    return q_l

def mk_bib_query (i, seq):
    return tables[i].bib_query (seq)

def mk_auth_stats_q ():
    return 'select auth_personal.seq, %s, count(am.bibno) from %s, auth_personal_map am where %s.seq = am.authno group by 1,2 order by 3 desc limit 20;' % (tables[1].sort_cols, tables[1].table, tables[1].table)

def mk_call_stats_q ():
    # How profoundly awful.
    return "select call_no.problem, call_no.class_text, count(call_no.bibno),max (foo.count) from call_no, (select count(seq) from main) as foo where ctr = 0 group by 1,2 order by 3 desc"


class query:
    def __init__ (self, dbg = None):
        self.conn = pgdb.connect (libspec)
        self.dbg = dbg
    def run (self, q):
        curs = self.conn.cursor ()
        curs.execute (q)
        r = curs.fetchall ()
        del curs

        if self.dbg <> None:
            self.dbg (q)
#           self.explain (q)
# ignore this until PQsetNoticeProcessor i/f is provided from Python.
# Until then, explain text just goes into Apache error log, easier to
# cut & paste into psql
        return r
    def explain (self, q):
        curs = self.conn.cursor ()
        curs.execute ('EXPLAIN ' + q)
        del curs
        return

if __name__ == '__main__':
    print
    q = query ()
    for i in range (len(tables)):
        to_run = mk_init_query (i, 'foo', 5, 0, 1)
        print to_run
        for e in q.run (to_run):
            print e

