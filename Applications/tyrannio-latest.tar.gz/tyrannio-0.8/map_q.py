#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import lucien
import merv
import full # for shortcut if only one bibno selected

fmt = merv.Formatter ()

pe = merv.ParmExtracter ()
pe.req_parm ('table', 'd')
pe.req_parm ('seq', 'd')
pe.opt_parm ('dbg', 'b', 0)

if __name__ == '__main__':
    if not pe.parse ():
        fmt.form_error ()
    else:
        fmt.page_begin ('Query')
        l = lucien.mk_intermed_query (pe['table'], pe['seq'])
        q = lucien.query(merv.make_dbg(fmt, pe['dbg']))
        titles = q.run (l)

        fmt.para_begin ()
        def one_elt (fmt, ctr, e):
            bibno, t_nonfile, t_file, call, relator = e
            fmt.emit_link (t_nonfile + t_file + call + relator,
                           'full.py', bibno=bibno)
        fmt.list_emit (one_elt, titles)
        fmt.page_end ()
