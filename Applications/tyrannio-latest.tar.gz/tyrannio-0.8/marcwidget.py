#!/usr/bin/env python

import gtk
from PyZ3950 import zmarc

class MarcWidget(gtk.GtkTree):
    def __init__ (self, *args):
        gtk.GtkTree.__init__ (self, args)
    def set_marc (self, data):
        self.clear_items (0, -1)
        self.mdat = data
        self.m = zmarc.MARC (data)
        fields = self.m.fields.keys ()
        fields.sort ()
        self.fixed = {}
        # maps fixed fields to GtkEntry
        
        self.fields = {}
        # maps nonfixed field to [indicator GtkEntrys, list of [sub, GtkEntry]]
        
        for fieldno in fields:
            prefix = str (fieldno) + ': '
            item_subtree_list = []
            if zmarc.is_fixed (fieldno): # XXX all fixed fields are NR?
                for fielddat in self.m.fields [fieldno]:
                    (edit, item) = self.make_subitem (
                        prefix, self.m.fields[fieldno][0])
                    self.fixed [fieldno] = edit
                    item_subtree_list.append ((item, None))

            else:
                self.fields [fieldno] = []
                for fielddat in self.m.fields[fieldno]:
                    subtree = gtk.GtkTree ()
                    subtree.show ()
                    s = fielddat[0] + fielddat [1]
                    postfix = ' '
                    editl = []
                    for (subind, subdat) in fielddat[2]:
                        (edit, subitem) = self.make_subitem (subind, subdat)
                        editl.append ((subind, edit))
                        subtree.append (subitem)
                        postfix += '$' + subind + ' '+ subdat
                    (edit, item) = self.make_subitem (
                        prefix, s, postfix, maxlen = 2)
                    self.fields[fieldno].append ((edit, editl))
                    item_subtree_list.append ((item, subtree))
            for (item, subtree) in item_subtree_list:
                self.append (item)
                if subtree <> None:
                    item.set_subtree (subtree)
    def make_subitem (self, prefix, dat, postfix = None, maxlen = None):
        # XXX doesn't need to be method
        hbox = gtk.GtkHBox ()
        lab = gtk.GtkLabel (prefix)
        lab.show ()
        hbox.pack_start (lab, expand = 0)
        edit = gtk.GtkEntry ()
        edit.set_text (dat)
        edit.show ()
        if maxlen <> None:
            edit.set_max_length (maxlen)
            edit.set_usize (25,20) # XXX should be a better way!
        expand = postfix == None
        
        hbox.pack_start (edit, expand = expand)

        if postfix <> None:
            lab = gtk.GtkLabel (postfix)
            lab.set_alignment (0, 0.5)
            lab.show ()
            hbox.pack_start (lab, expand = 1, fill = 1)
        hbox.show ()
        item = gtk.GtkTreeItem ()
        item.add (hbox)
        item.show ()
        return (edit, item)
    def get_MARC (self):
        m = zmarc.MARC ()
        for (field, val) in self.fixed.items ():
            m.fields [field] = [val.get_text ()]

        for (field, val) in self.fields.items ():
            m.fields [field] = []
            for (ind, subval) in val:
                ind_text = ind.get_text ()
                nsubval = map (lambda x: (x[0], x[1].get_text()), subval)
                m.fields [field].append ((ind_text[0], ind_text[1],
                                            nsubval))
        m.ok = 1
        return m.get_MARC ()
    def clear (self):
        pass
