#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import urllib
import string
import cgi
import os

# Merv [Pumpkinhead] does the grunt work of producing correctly formatted
# and escaped HTML.  It doesn't abstract as much as one might like,
# but it's enough for now.

def _quote (s):
    return cgi.escape (s, 1) # XXX need to escape quotes also?

def _make_url (url_base, parms):
    url = url_base
    if len (parms) <> 0:
        app_l = []
        for parm in parms.keys ():
            app_l.append (urllib.quote (parm) + '=' +
                          urllib.quote (str(parms[parm])))
        # urllib.quote quotes all HTML special characters, no need to _quote
        url = url + '?' + string.join (app_l, '&amp;')
    return url

class Formatter:
    def __init__ (self):
        self.begin_sent = 0
    # Call page_begin b/f any fn other than form_error
    def page_begin (self, title):
        self.begin_sent = 1
        print "Content-type: text/html"
        print
        print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">'
        print "<html><head><title>" + _quote (title) + "</title></head><body>"
    def page_end (self):
        print """<p><a href="http://www.pobox.com/~asl2/software/Tyrannio/"><small><small>
        <small>Lucien Front End to Tyrannio</small></small></small>"""
        print "</body></html>"
    def form_error (self):
        if not self.begin_sent:
            self.page_begin ("Error")
        print "<H1>Error: form passed incorrect parms</H1>" # XXX - redirect to orig. form?
        self.page_end ()
    def para_begin (self):
        print "<p>"
    def para_end (self):
        print "</p>"
    def line_end (self):
        print "<br>"
    def list_begin (self):
        print "<ul>"
    def list_elt_begin (self):
        print "<li>"
    def list_elt_end (self):
        print "</li>"
    def list_end (self):
        print "</ul>"
    def list_emit (self, fn, l, rev = 0):
        self.list_begin ()
        if rev:
            r = range (len(l) -1, -1, -1)
        else:
            r = range (0, len(l))
        for i in r:
            self.list_elt_begin ()
            fn (self, i, l[i])
            self.list_elt_end ()
        self.list_end ()
    def emit_text (self, text):
        print _quote (text)
    def emit_link (self, label, url_base, **parms):
        print '<a href="%s">%s</a>' % (_make_url(url_base, parms), _quote (label))
    def heading (self, val, text):
        print "<H%d>%s</H%d" % (val, _quote (text), val)
    def emit_raw (self, text):
        print text
        
    def redirect (self, url_base, **parms):
        if self.begin_sent:
            print "Internal error: redirecting after begin_sent"
        else:
            redir_url = _make_url (url_base, parms)
            print "Status: 302"
            # It might be nice if apache 1.3.19 canonicalized relative URLs
            # passed back in Location:, but it doesn't, and the RFC specifies
            # an absolute URL.  The draft CGI 1.2 spec claims it's OK to send
            # a fragment, and mutters about this being used for
            # server-internal redirection.
            # Currently, I punt and don't use this code at all, relying
            # instead on directly
            # calling one python script from another (see map_q.py)
            cur_uri = os.environ ['SCRIPT_NAME']
            ind = string.rfind (cur_uri, '/')
            if (ind <> -1):
                redir_url = 'http://' + os.environ ['HTTP_HOST'] + cur_uri [0:ind+1] + redir_url
            
            print "Location:", redir_url 
            print

class ParmExtracter:
    def __init__ (self):
        self.opt_dict = {}
        self.reqd_dict = {}
        self.vals_dict = {}
        self.form = cgi.FieldStorage ()
    def req_parm (self, name, typ):
        self.reqd_dict[name] = typ
    def opt_parm (self, name, typ, val):
        self.opt_dict [name] = (typ, val)
    def parse_one (self, nm, v, typ):
        if typ == 'd':
            return string.atoi (v)
        elif typ == 'b':
            uc_v = string.upper (v)
            if uc_v == 'ON':
                return 1
            elif uc_v == 'OFF':
                return 0
            else:
                return string.atoi(v)
        elif typ == 's': # string
            return v
        else:
            raise "Bogus type!!" + typ + nm
    def parse (self):
        try:
            for nm in self.reqd_dict.keys ():
                v = self.parse_one (nm, self.form[nm].value,
                                    self.reqd_dict[nm])
                self.vals_dict[nm] = v
        except KeyError:
            return 0
        for nm in self.opt_dict.keys ():
            (typ, def_val) = self.opt_dict [nm]
            if self.form.has_key (nm):
                v = self.parse_one (nm, self.form[nm].value, typ)
            else:
                v = def_val
            self.vals_dict[nm] = v
        return 1
    def __getitem__ (self, key):
        return self.vals_dict [key]
    
def make_dbg (fmt, dbg):
    if dbg:
        def dbg_fn(s,fmt=fmt):
            fmt.emit_text (s)
        return dbg_fn
    else:
        return lambda s: None

        

            
        
        


