#!/usr/bin/env python
import sys
import compileall
# This is just a hack so we can avoid specifying /usr/lib/$(PYTHON_LIB_DIR)
# in the Makefile, and this seems easier than trying to figure out where
# to get PYTHON_LIB_DIR.


if __name__ == '__main__':
    sys.exit (not compileall.main())
