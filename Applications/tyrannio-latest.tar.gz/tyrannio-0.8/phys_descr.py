#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import re
import string

roman_re = r"(?:([mdclxvi]+), )?"
regex = roman_re + r"(\d+) p\.(?!l.)"
extent_pages_re = re.compile (regex) # exclude p.l., typo for pl., plates

rdict = {'m': 1000,'d': 500, 'c': 100, 'l':50,'x':10,'v':5,'i':1}

def roman_to_dec (r): # XXX this fails to signal errs on invalid input
    if r == None:
        return 0
    cur = 0
    last = 0
    vals = map (rdict.get, r)
    if None in vals:
        print r
        print vals
    for digit in vals:
        if digit > last and last <> 0:
            cur = cur + (digit - last)
            last = 0
        else:
            cur = cur + last
            last = digit
    return cur + last
            

def parse (s):
    m = extent_pages_re.search (s)
    if m <> None:
        gr = m.groups ()
        if len (gr) == 1:
            return (string.atoi (gr[1]),0)
        else:
            return (string.atoi (gr[1]),roman_to_dec (gr[0]))
    return (0,0)

field_names = ['main_pages', 'preface_pages']

if __name__ == '__main__':
    import util
    import pgdb
    libstring = util.get_libname ()
    conn = pgdb.connect (libstring)
    curs = conn.cursor ()
    curs.execute ('SELECT extent FROM phys_descr ORDER BY bibno')
    l = map (lambda s: (s[0], parse(s[0])), curs.fetchall ())
    def cmpfnc (a,b):
        for i in range (len(field_names)):
            if a[1][i] < b[1][i]:
                return -1
            if a[1][i] > b[1][i]:
                return 1
        return 0
    l.sort (cmpfnc)
    for foo in l:
        print foo
    

