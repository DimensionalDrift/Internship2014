#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import lucien
import merv
import string

def prevnext (fmt, table, key, prevflag, wcpattern, bibno, limit):
    text = ['Next', 'Prev'] [prevflag]
    fmt.emit_link (text, 'query.py', table=table, key=key,
                   wcpattern=wcpattern, bibno=bibno,
                   rev=prevflag, limit = limit)
    

fmt = merv.Formatter ()
fmt.page_begin ('Query')
fmt.para_begin ()

pe = merv.ParmExtracter ()
pe.req_parm ('table', 'd')
pe.opt_parm ('key', 's', '')
# specifying "key=&..." to cgi is same as not specifying it?
pe.opt_parm ('limit', 'd', 20)
pe.opt_parm ('wcinit', 'b', 0)
pe.opt_parm ('wcpattern', 's', '')
pe.opt_parm ('rev', 'b', 0)
pe.opt_parm ('dbg', 'b', 0)
pe.opt_parm ('bibno', 'd', 0)
pe.opt_parm ('init', 'b', 0)

if not pe.parse ():
    fmt.form_error ()
else:
    q = lucien.query (merv.make_dbg (fmt, pe['dbg']))

    if pe['wcinit']:
        key = ''
        wcpattern = pe['key']
    else:
        key = pe['key']
        wcpattern = pe['wcpattern']

#  XXX following is annoying hack.  We recognize where we are in the
#  by-page sort by reparsing the physical description string, instead of
#  carrying the value around.  But we don't want to force the user to
#  type in <number><space>p., which is the way we recognize where the #
#  of pages is.  We could fix this by retrieving the # of pages instead
#  of reparsing, or just carrying around the bibno as the key (and using
#  a nested select to retrieve the appropriate key for ordering.)


    if pe ['init'] == 1 and pe['wcpattern'] == '':
        table_name = lucien.tables[pe['table']].table
        if table_name == 'phys_descr':
            key = key + ' p.'

    
    q_text = lucien.mk_init_query (pe['table'], key, pe['limit'], pe['rev'],
                                       wcpattern, pe['bibno'])
    res = q.run (q_text)
    is_mapped = lucien.is_mapped (pe['table'])
    if len (res) == 0:
        fmt.emit_text ("No more records")
    # XXX more friendly to wrap, or at least indicate b/f clicking
    else:
        if pe['rev']:
            r = range (len(res) - 1, -1, -1)
        else:
            r = range (0, len(res))
        prevnext (fmt, pe['table'], res[r[0]][2], 1, wcpattern,
                  res[r[0]][0], pe['limit'])
        
        def one_elt (fmt, i, e, is_mapped = is_mapped):
            if is_mapped:
                count = e[3]
                if count > 1:
                    fmt.emit_link (e[1] + e[2], 'map_q.py',
                                   table=pe['table'], seq = e[0])
                else:

#  One could argue that doing all this extra query work here is bad,
#  because most of it won't get used.  I used to instead have code in
#  map_q to shortcut to full, but that means more URLs floating around,
#  and that the already-visited indication in the browser doesn't work as
#  well.

                    l = lucien.mk_intermed_query (pe['table'],e[0])
                    bibs = q.run (l)
                    for r in bibs:
                        assert (r[0] == bibs[0][0])
                    fmt.emit_link (e[1] + e[2], 'full.py', bibno=bibs[0][0])
                fmt.emit_text ('(%d)' % (count,))
            else:

                if pe['table'] == 0:
                    s = e[1] + e[2]
                else:
                    s = e[1] + e[2] + e[3]
                s = string.join (e[1:])
                fmt.emit_link (s, 'full.py', bibno=e[0])
                
        fmt.list_emit (one_elt, res, pe['rev'])
        fmt.para_begin ()
        prevnext (fmt, pe['table'], res[r[-1]][2], 0,
                  wcpattern, res[r[-1]][0], pe['limit'])
        fmt.page_end ()


    




