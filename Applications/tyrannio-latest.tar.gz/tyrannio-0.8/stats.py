#!/usr/bin/env python
# Tyrannioware: a book cataloging program
# Copyright (C) 2001 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import lucien
import merv

fmt = merv.Formatter ()
pe = merv.ParmExtracter ()
pe.req_parm ('stat', 'd')
pe.opt_parm ('dbg', 'b', 0)

# XXX should handle nonpersonal authors (corp. and mtg), but not
# nearly as interesting
def fmt_auth (fmt, i, e):
    fmt.emit_link (e[1], 'map_q.py', table=1, seq=e[0])
    fmt.emit_text ('(%d)' % e[2])

def fmt_call (fmt, i, e):
    prob_or_class = e[0] + e[1]
    fmt.emit_link (prob_or_class, 'query.py', table=4, key=prob_or_class)
    fmt.emit_text ('(%d--%.2f%%)' % (e[2],e[2] * 100.0 /e[3]))
    
stats_def = [(lucien.mk_auth_stats_q, 'Most frequent authors', fmt_auth),
             (lucien.mk_call_stats_q, 'Call number breakdown', fmt_call)]

if __name__ == '__main__':
    if not pe.parse ():
        fmt.form_error ()
    else:
        to_call, title, fmtfn = stats_def [pe['stat']]
        fmt.page_begin (title)
        q = lucien.query (merv.make_dbg (fmt, pe['dbg']))
        res = q.run (to_call ())
        fmt.list_emit (fmtfn, res)
    fmt.page_end ()
    







