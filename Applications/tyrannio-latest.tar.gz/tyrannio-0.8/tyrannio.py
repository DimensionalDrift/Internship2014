#!/usr/bin/env python

# Tyrannioware: a book cataloging program
# Copyright (C) 2001-2 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import cuecat_inp
import os
import string
import select
import popen2
import sys
from PyZ3950 import zmarc, zoom
import pgdb # XXX make this genericizable
import types
import re
import call
import book_nos
import traceback
import util
import thread


z3950ind = 0 # index into following table

z3950host = [("lc", "z3950.loc.gov", 7090, "VOYAGER"),
         ("nlc", "amicus.nlc-bnc.ca", 210, "NL")]

# we may well need more per-library info.  For example, from non-LC-call-using
# libraries (like Oxford, UK), we want to ignore 852 records, since they
# contain non-LC call numbers, but that's the only place LC-style call
# #s appear in the NLC-BNC

dup_call_dbs = ["nlc"]

use_threads = 0
n_threads = 4


# we preprocess our translation dictionaries in order to make
# writing and using them a little clearer.  (The other option
# would be a class derived from UserDict, which would store the original
# form and provide the new behavior at access time.)  We:
# - translate a tuple as index into dictionary keys for each element
#   of the list.  (Tuples as tuple elements indicate an inclusive
#   range)
# - plain strings as keys are turned into lambdas which ignore
#   their values and return the string.
# the argument to the lambda is a ParseObj, w/ fields:
# - ind1, ind2 (MARC indicator values)
# - val (payload of current subfield)
# - fieldno (MARC field)
# - sub (current MARC subfield)
# - col (current SQL column name)
# - isbn (current book ISBN #), used only to mark which ISBN #


class ParseObj:
    def __init__ (self, isbn, db = ''):
        if isbn <> None:
            isbn = string.upper (isbn)
        self.isbn = isbn
        # user can type in ISBNs w/either upper/lower case X check digit
        self.db = db

def xl_subdict (sd):
    if type (sd) == types.StringType or type(sd) == types.LambdaType:
        return sd
    nsd = {}
    for subfield,col in sd.items ():
        if type (col) == types.FunctionType:
            nc = col
        else:
            nc = lambda pobj, col = col: ([col], [pobj.val]) 
        nsd [subfield] = nc
    return nsd
            
def exp_keys (k):
    if type (k) == types.IntType:
        return [k] # otherwise a tuple
    else: return k

#  A previous design didn't bother with partitioning, and just looked up
#  each field in each dictionary (deleting as we went).  Profiling
#  revealed this lookup to be wastefully expensive.  (Iterating over the
#  dictionary checking for present fields would also have been
#  expensive.)  Thus, the FieldToTbl machinery and partition_marc below.
#  (As a fringe benefit, we can also check that the same MARC field
#  doesn't appear in two different dictionaries.)

class FieldToTbl:
    def __init__ (self):
        self.fieldno_to_tbl = {}
        self.misc_tbl = ''
    def register_field (self, tbl, field):
        if type(field) == type (()):
            (lo, hi) = field
            for i in range (lo, hi + 1):
                self.register_field (tbl, i)
        elif type (field) == type (None):
            self.misc_tbl = tbl
        else:
            if self.fieldno_to_tbl.has_key(field):
                print "WARNING: redefining field", field, " from ", \
                      self.lookup_field(field), " to ", tbl
            self.fieldno_to_tbl [field] = tbl
    def lookup_field (self, field):
        if self.fieldno_to_tbl.has_key (field):
            return self.fieldno_to_tbl[field]
        else:
            return self.misc_tbl

    
class FieldDict:
    field_to_tbl = FieldToTbl ()
    tbl_to_dict = {}
    def __init__ (self, tbl, dict, endfn = None, ctr_reqd = 0, multiline = 1,
                  merge_intraline_rpt = 0, ign_dups = 0):
        FieldDict.tbl_to_dict [tbl] = self
        if type(dict) == type ({}):
            self.ndict = {}
            for k, v in dict.items ():
                nv = xl_subdict (v)
                for fieldno in exp_keys(k):
                    self.ndict [fieldno] = nv
                    FieldDict.field_to_tbl.register_field (tbl, fieldno)
            self.lookup = self.lookup_dict
        elif type(dict) == type(()):
            self.lookup = self.lookup_tuple
            t, self.data = dict
            if type(t) == type(()):
                self.lo, self.hi = t
                FieldDict.field_to_tbl.register_field (tbl, t)
            elif type(t) == type(None):
                self.lookup = self.lookup_misc
                FieldDict.field_to_tbl.register_field (tbl, None)
            
        self.endfn = endfn
        self.ctr_reqd = ctr_reqd
        self.multiline = multiline
        self.merge_intraline_rpt_default = merge_intraline_rpt
        self.ign_dups = ign_dups
        self.mir_override = {}
    def override_merge_intraline (self, fieldseq, val):
        for field in fieldseq:
            self.mir_override[field] = val
    def get_merge_intraline (self, fieldno):
        return self.mir_override.get (fieldno,
                                      self.merge_intraline_rpt_default)
    def lookup_dict (self, fieldno):
        if self.ndict.has_key (fieldno):
            # expect to fail a lot, use has_key not exn
            return self.ndict[fieldno]
        else:
            return None
    def lookup_tuple (self, fieldno):
        if fieldno >= self.lo and fieldno <= self.hi:
            return self.data
        return None
    def lookup_misc (self, fieldno):
        return self.data


def bool_to_sql (bool):
    if (bool):
        return 't'
    else:
        return 'f'

def ind_to_int (nonfile_ind):
    if nonfile_ind >= '0' and nonfile_ind <=  '9':
        return ord(nonfile_ind) - ord('0')
    else:
        return 0

articles = ['a', 'an', 'the']
def guess_noncoll (title): # XXX should respect language indicator
    for try_art in articles:
        art = try_art + ' '
        art_len = len(art)
        if string.upper(title[:art_len]) == string.upper(art):
            return art_len
    return 0

#  XXX would be better to handle title prefixes with an integer in the
#  database and expand w/ a view or in the front end, but that makes it
#  harder to handle 246 $i where the display text is explicitly given.  I
#  probably should define an insert trigger on the view which assigns a
#  new index >= 10, and does the appropriate inserts on the underlying
#  tables.

title_types = ['',
               # portion, or, b/c ind_to_int is 0 for nondigits,
               # no type specified
               '', # parallel
               'Distinctive title',
               'Other title',
               'Cover title',
               'Added title page title',
               'Caption title',
               'Running title',
               'Spine title']
        
def title_fn(pobj):
    fieldno = pobj.fieldno
    if fieldno == 490 or fieldno == 246:
        noncoll_len = guess_noncoll (pobj.val)
    else:
        if fieldno == 730 or fieldno == 130 or fieldno == 740:
            nonfile_ind = pobj.ind1
        else: # 245, 440, 240, 830
            nonfile_ind = pobj.ind2
        noncoll_len = ind_to_int (nonfile_ind)
    prim_flag = bool_to_sql (fieldno == 245 or fieldno == 440)
    unif_flag = bool_to_sql (fieldno == 130 or fieldno == 240 or
                             fieldno == 730 or fieldno == 830)
    cols = ['prefix', 'suffix', 'primary_flag', 'uniform_flag']
    vals = [pobj.val[0:noncoll_len], pobj.val[noncoll_len:],
            prim_flag, unif_flag]
    if fieldno == 246:
        title_type = title_types[ind_to_int(pobj.ind2)]
        if title_type <> '':
            cols.append ('title_type')
            vals.append (title_type + ': ')
    return (cols, vals)

def src_acc_fn (pobj, line):
    return (['src_accession_no', 'src_accession_code'],
            [line, pobj.db])

main_dict = FieldDict ('main',
    {1: src_acc_fn,
     10: {'a': 'lccn'},
     250: {'a': 'edition_stmt_1',
           'b': 'edition_stmt_2'}}, multiline = 0)


call_no_dict = FieldDict ('call_no',
    {50: {'a': 'class',
          'b': 'item'},
     # in LC, I've never seen 852 to carry a call #, but it's the only
     # place I see a call in the NLC-BNC (Canada) NL database
     852: {'h': 'class',
           'i': 'item'}}, ctr_reqd=1, ign_dups = 1)

#  XXX call_no FieldDict ign_dups should only be for field 852.  We need
#  it b/c the only place NLC-BNC has LC-style classification is in 852,
#  but that has an entry for each holding: so if NLC-BNC has more than
#  one copy, we'd generate a dup fieldno.  Extend and generify the
#  mir_override mechanism so we only do ign_dups for 852

pub_info_dict = FieldDict ('pub_info',
    {260: {'a' : 'place',
           'b' : 'name',
           'c' : 'date',
           'e' : 'mfg_place',
           'f' : 'mfg_name',
           'g' : 'mfg_date'}}, ctr_reqd=1)

title_sub_dict = {'a': title_fn,
                  'b': 'subtitle',
                  'c': 'resp_stmt',
                  'f': 'date',
                  'h': 'medium',
                  'i': 'title_type',
                  'k': 'form',
                  'l': 'language',
                  'n': 'number',
                  'p': 'part',
                  's': 'version'
                  }

# XXX actually $c is invalid for 246, presumably b/c the resp. stmt should
# be the same for varying titles as for orig. titles.  'i' only valid for 246.

title_dict = FieldDict ('title',
    {(245,
      246,
      740, # XXX what's the difference between this and 246?
      130, # these onward unif. title
      240,
      730): title_sub_dict})

series_800_sub  = {'a': 'suffix',
                   'b': 'suffix', # 810 org.
                   'l': 'suffix', # language
                   'd': 'suffix', # dates
                   'f': 'suffix', # date of work
                   'q': 'suffix', # fuller name
                   't': 'subtitle',
                   'v': 'vol'}

series_dict = FieldDict ('series',
                         {(440,490, 830): {'a': title_fn,
                                   'l': 'lc_call',
                                   'n': 'part_no',
                                   'p': 'part_name',
                                   'x': 'issn',
                                   'v': 'vol'},
                          (800,810,811) : series_800_sub})

series_dict.override_merge_intraline ((800,810,811), 1)

#  merging intraline rpts needed for 800,810,811, prohibited for 440,
#  490.  This would be easier if instead of repeating $a for 440, 490,
#  the whole line was repeated as necessary.
                       

import phys_descr

def extent_fn (pobj):
    cols = ['extent']
    vals = [pobj.val]
    p = phys_descr.parse (pobj.val)
    for i in range(len (p)):
        if p[i] <> None:
            cols = cols + [phys_descr.field_names [i]]
            vals = vals + [p[i]]
    return (cols, vals)


phys_descr_dict = FieldDict ('phys_descr',
                             {300: {'a': extent_fn,
                                    'b': 'other_details',
                                    'c': 'dimensions',
                                    'e': 'accompanying',
                                    'f': 'unit_type',
                                    'g': 'unit_size',
                                    '3': 'mat_specified'}}, ctr_reqd=1)

def isbn_fn(pobj):
    isbn = pobj.val
    present = 0
    if pobj.isbn <> None:
        # pobj.val may have some additional punctuation or description,
        # so don't use = XXX isbn in MARC data is gteed to have uppercase X?
        present = -1 <> string.find (isbn, pobj.isbn)
        if present:
            pobj.isbn = None

    i = string.find (isbn, '(')
    cols = []
    vals = []
    if i <> -1:
        fmt = isbn [i:]
        isbn = isbn[:i]
        cols = ['fmt']
        vals = [fmt]
    cols = cols +  ['isbn', 'valid', 'present']
    vals = vals +  [isbn, bool_to_sql(pobj.sub == 'a'), bool_to_sql (present)]
    return (cols, vals)

def isbn_end_fn (pobj, cv):
    if pobj.isbn <> None:
        print "adding isbn", pobj.isbn
        # XXX actually we have no idea if this ISBN is valid
        cv.add_cvs (['isbn', 'valid', 'present'],
                    [pobj.isbn, bool_to_sql (1), bool_to_sql (1)], 20)
        
    
isbn_dict = FieldDict ('isbn',
                       {20: {'a': isbn_fn,
                             'b': 'fmt', # obsolete, but present in old records
                             'c': 'avail_terms',
                             'z': isbn_fn}}, endfn=isbn_end_fn)


auth_pers_subfields = {'a': 'name',
                  'b': 'numeration',
                  'c': 'title', 
                  'd': 'dates',
                  'e': 'relator',
                  '4': 'relator', 
                  'g': 'misc',
                  'q': 'fuller_name'}

auth_personal_dict = FieldDict ('auth_personal',
                            {(100,700) : auth_pers_subfields},
                                merge_intraline_rpt = 1)

auth_corp_subfields = {'a': 'corp_juris_name',
                       'b': 'subord_unit',
                       'c': 'mtg_loc',
                       'd': 'date', # date of meeting or treaty signing
                       'f': 'date', # date of work (name-title only?)
                       'e': 'relator',
                       '4': 'relator', 
                       'g': 'misc',
                       'k': 'misc', # form subheading
                       'l': 'language',
                       'n': 'number_part_section',
                       'p': 'name_part_section',
                       'u': 'affiliation_address'};

auth_corp_dict = FieldDict('auth_corp',
                           {(110, 710): auth_corp_subfields},
                           merge_intraline_rpt = 1)

auth_mtg_dict = FieldDict('auth_mtg',
                          {(111, 711): {'a' : 'name_or_juris_name',
                                      'c' : 'loc',
                                      'd' : 'date',
                                      'e' : 'subord_unit',
                                      'n' : 'number',
                                      'q' : 'sub_name',
                                      '4' : 'relator'}},
                          merge_intraline_rpt = 1)

def subj_fn (pobj, line):
    fieldno = pobj.fieldno
    (ind1, ind2, sublist) = line
    subj = ''
    source = ''
    for (subfield, val) in sublist:
        if subfield == '2':
            source = source + val
        else:
            sep = ''
            if subfield in ['v', 'x','y','z']:
                sep = '--'
            else:
                if subj <> '':
                    sep = ' '
            subj = subj + sep + val
    if fieldno == 630:
        noncoll_len = ind_to_int (ind1)
    else:
        noncoll_len = 0
    return (['fieldno', 'ind1', 'ind2', 'prefix', 'subj', 'source'],
            [fieldno, ind1, ind2, subj[0:noncoll_len],
             subj[noncoll_len:], source])
    
subj_dict  = FieldDict ('subj',((600, 658), subj_fn))
notes_dict = FieldDict ('notes',((500, 599), 'note'))
misc_dict  = FieldDict ('misc',(None, 'data'))


# XXX 600-630 are subject to the same authority control as [17][0-3][0-9],
# for the $[abcd] subfields, and perhaps should go into the same authority
# db, but we'd still need to put $x in a separate subject control.  Yuck.

electronic_link_dict = FieldDict ('electronic_link',
                                  {856: {'g' : 'urn',
                                         'u' : 'url',
                                         'z' : 'note',
                                         '3' : 'mat_specified'}})

def find_xl (sub_dict, sub):
    return sub_dict.get (sub, None)



def stringify_sublist (sub):
    s = ""
    for f in sub:
        s = s + "$" + f[0] + " " + f[1]
    return s

# XXX known_ should be coded as lists for ease of reading, converted
# to dicts for random-acc. speed

known_rpts = {
    (20,'a'):1,
    (20,'z'):1,
    (50,'a'):1,
    (110,'b'):1,
    (260,'a'):1,
    (260,'b'):1,
    (300,'a'):1,
    (300,'b'):1,
    (300,'c'):1,
    (490,'a'):1,
    (700,'4'):1,
    (700,'e'):1,
    (710,'b'):1,
    (800,'d'):1,
    (800,'f'):1,
    (800,'l'):1,
    (800,'q'):1,
    (810,'b'):1}
               
def check_print_dup (field, sub):
    return not known_rpts.get ((field,sub),0)

known_ignore = {
    (10,'z'):1,
    (50,'u'):1, # not documented, but looks like LC-specific loc info
    (700,'f'):1,
    # next 700 fields are part of author-title records, not supported XXX
    (700,'l'):1,
    (700,'k'):1,
    (700,'t'):1,
    (710,'5'):1,
    # XXX actually the presence of a '5', institution to which this applies
    # sometimes means that we should ignore the record entirely
    (852,'x'):1,
    (852,'9'):1,
    (852,'a'):1,
    (852,'c'):1,
    (852,'t'):1,
    (852,'z'):1,
    (856,'2'):1
    # not quite right: we should only ignore if scheme not part of $u url
    }
    

def check_print_ignore (field, sub):
    return not known_ignore.get ((field,sub),0)

class ColsVals:
    def __init__ (self, ctr_reqd, cont, ign_dups):
        self.cvlist = []
        self.ctr_reqd = ctr_reqd
        self.ign_dups = ign_dups
        self.cont = cont
    def add_cvs (self, cols, vals, fieldno):
        cols, vals = self.cont (cols, vals, fieldno)
        tpl = (cols, util.quote_list (vals))
        if self.ign_dups and tpl in self.cvlist:
            print "Ignoring duplicate cols_vals", tpl
            return
        self.cvlist.append (tpl)
    def get_cvs (self):
        if self.ctr_reqd:
            nlist = []
            # should set ctr = 0 per-SQL-table, not per-colsvals, but close
            # enough, since none of the ctr-requiring fields integrate
            # more than one fieldno into a table
            ctr = 0
            for cols, vals in self.cvlist:
                cols.append ('ctr')
                vals.append ('%d' % ctr)
                ctr = ctr + 1
                nlist.append ((cols, vals))
            return nlist
        return self.cvlist

def massage_line (fieldno, line, sub_dict, multiline, merge_intraline_rpt, pobj, cols_vals):
    cols = []
    vals = []
    pobj.fieldno = fieldno
    if not zmarc.is_fixed (fieldno):
        (ind1, ind2, sublist) =  line
    # do we just stringify the entire line?
    if type (sub_dict) == types.StringType:
        if zmarc.is_fixed (fieldno):
            v = line
        else:
            v = stringify_sublist (sublist)
            cols.append ('ind1')
            vals.append (ind1)
            cols.append ('ind2')
            vals.append (ind2)
        cols.append (sub_dict)
        vals.append (v)
        cols_vals.add_cvs (cols, vals, fieldno)
        return 
    elif type (sub_dict) == types.LambdaType:
        cols, vals = sub_dict (pobj, line)
        cols_vals.add_cvs (cols, vals, fieldno)
        return

    seen_cols = {}

    pobj.ind1 = ind1
    pobj.ind2 = ind2


    for (sub,val) in sublist:
        xl = find_xl (sub_dict, sub)
        if (xl <> None):
            changed = 1
            pobj.val = val
            pobj.sub = sub
            (collist, vallist) = xl(pobj)
            if len (collist) <> len(vallist):
                raise "Bogus collist/vallist", (collist,vallist)
# IWBN to get away with just one of seen_cols and cols. cols needs to
# be a list for ||ism w/ vals.  seen_cols is dict for faster random
# access (but most tables only have 5-10 cols...)
            for i in range(len(collist)):
                col = collist [i]
                if seen_cols.has_key (col):
                    do_print = check_print_dup (fieldno, sub)
                    if do_print: print "WARNING: dup", fieldno, sub, col, val,
                    if merge_intraline_rpt:
                        old_ind = seen_cols[col][0]
                        if do_print:
                            print "Merging w/ ", seen_cols [col], \
                                  cols [old_ind]
                        vals [old_ind] = vals[old_ind] + vallist[i]
                        # only for strings
                        continue
                    else:
                        if not multiline:
                            print "IGNORED, old ", seen_cols[col]
                        else:
                            if do_print: print "new row"
                            cols_vals.add_cvs (cols, vals, fieldno)
                            cols = []
                            vals = []
                            seen_cols = {}
                cols.append (col)
                vals.append (vallist[i])
                seen_cols [col] = (len(cols) - 1, vallist[i])
        else:
            if check_print_ignore (fieldno, sub):
                print "WARNING: Ignoring", fieldno, sub, val
    if (cols <> []):
        cols_vals.add_cvs (cols, vals, fieldno)
    return

def defcont(cols, vals, ign):
    return (cols, vals)

# only currently called for main table
def flatten (qlist):
    ncols = []
    nvals = []
    for (cols, vals) in qlist:
        assert (len(cols) == len (vals))
        for i in range (len(cols)):
            if cols [i] in ncols:
                print "WARNING: dup column in flatten", cols[i], vals[i]
                continue
            ncols.append (cols[i])
            nvals.append (vals[i])
    nqlist = (ncols, nvals)
    return [nqlist]


def join_list (vals, sep):
    s = ""
    l = len (vals)
    for i in range(l):
        s = s + vals[i]
        if (i <> l - 1):
            s = s + sep
    return s

def my_find (key, cols, vals, default=None):
    try:
        ind = cols.index (key)
    except ValueError:
        return default
    return vals[ind]


#  We do this b/c author MARC fields will have a ',' proceeding the
#  relator when it's present, thus generating a different authority
#  record from relatorless ones if we don't strip the comma.  XXX should
#  only strip_relator_comma if author?  For series, if we use this, need
#  to avoid stripping computed columns (prim_flag, uniform_flag)
#  (i.e. arranging cols correctly to make it easier to find the one to
#  sttrip is necessary.)

def strip_relator_comma (nm):
    # XXX obviously we're doing the quoting too early, so we have to
    # strip and requote.  Yuck
    nm = nm[1:-1]
    if nm[-1] == ',':
        if nm[-2] == '.':
            # don't generate 2 '.'s if name ends w/ middle initial
            nm = nm [0:-1]
        else:
            nm = nm [:-1] + '.'
    nm = "'" + nm + "'"
    return nm

# XXX use remove instead?
def calc_relator_dict (auth_list, relator_col_name):
    new_auth_list = []
    rel_dict = {}
    for i in range (len(auth_list)):
        (cols, vals) = auth_list[i]
        newcols = []
        newvals = []
        assert (len(cols) == len (vals))
        for j in range (len(cols)):
            if (cols[j] <> relator_col_name):
                newcols.append (cols[j])
                newvals.append (vals[j])
            else:
                if len(newvals) > 0:
                    newvals[-1] = strip_relator_comma (newvals[-1])
                else:
                    print 'WARNING: relator first, unable to strip comma', \
                          auth_list
                assert (not (rel_dict.has_key (i)))
                rel_dict[i] = vals[j]
        new_auth_list.append ((newcols, newvals))
    return (new_auth_list, rel_dict)

def print_call (line):
    if use_threads:
        print thread.get_ident (),
    print "Call no: ", line
    # XXX quick hack to get callno printed
# yes, this isn't thread_safe.  It's a quick hack to assure us all
# threads are progressing, so correctly associating thr_id w/ call_no
# is irrelevant

marc_ext = ".marc"
isbn_ext = ".isbn"
edit_ext = ".edit"
fn_ext_len = len (marc_ext)

test = 0
def write_marc_file (db, mdat, isbn = None):
    save_dir = db + "_acc"
    if test:
        save_dir = "test_" + save_dir
    try:
        os.makedirs (save_dir)
    except OSError:
        # If it wasn't 'already exists', we'll lose later.
        # is there a cross-platform way to check what kind of err it was?
        pass
    # XXX check for overwriting
    base_name = save_dir + "/" + string.strip(mdat.fields[1][0])
    # MARC 001, internal control #, should be, er, most unique key
    tmpfile = open (base_name + marc_ext, "w")
    tmpfile.write (mdat.marc)
    if isbn <> None:
        print ("Writing isbn")
        tmpfile.close ()
        tmpfile = open (base_name + isbn_ext, "w")
        tmpfile.write (isbn)
    tmpfile.close ()


class MARC_to_SQL:
    def __init__(self, marcdat, conn, isbn, db):
        if not marcdat.ok:
            return
        write_marc_file (db, marcdat, isbn)
        self.partition_marc (marcdat)
        self.conn = conn
        self.curs = None
        self.isbn = isbn
        self.db = db
        try:
            self.run ()
        except pgdb.DatabaseError, err:
            print "WARNING: Database err", err
            if self.curs <> None:
                self.conn.rollback ()
        except:
            print "WARNING: exception importing",  traceback.print_exc ()

    # this function is used either to collect data from the whole MARC
    # record into a single database row (useable for a collection of MARC
    # fields  marked NR), or to collect data from a repeated set of
    # fields (e.g. 100, 700) into a set of database rows, depending on
    # the setting of the multiline flag.

    # We assume multiline, and then flatten if we were wrong.
    def massage_marc (self,table, cont = defcont):
        field_dict = FieldDict.tbl_to_dict[table]
        cols_vals = ColsVals (field_dict.ctr_reqd, cont, field_dict.ign_dups)
        pobj = ParseObj (self.isbn, self.db)

        for fieldno,lines in self.partitioned_marc[table].items ():
            sub_dict = field_dict.lookup (fieldno)
            for line in lines:
                massage_line (fieldno, line, sub_dict, field_dict.multiline,
                              field_dict.get_merge_intraline (fieldno),
                              pobj, cols_vals)

        if field_dict.endfn <> None:
            field_dict.endfn (pobj, cols_vals)
        ret = cols_vals.get_cvs ()
        if not field_dict.multiline:
            ret = flatten (ret)
        return ret

    def mk_insert (self, tbl, cols, vals):
        return ("INSERT INTO %s (%s) VALUES (%s)" %
                   (tbl, join_list (cols, ','), join_list (vals, ',')))
    
    def exec_simplelist (self, stmtlist):
        # give the database api a chance to pipeline all these inserts,
        # since we don't use the returnedf OID from these INSERTs and
        # anything going wrong here is kinda fatal.
        self.curs.executemany ('%s', stmtlist)

    # call w/ curs == None if insert can fail due to duplicate unique values,
    # since there's always the possibility of a race condition which
    # will abort the entire xaction (no, we can't fix this by moving the
    # select first, in the multiuser case).

    def exec_querylist (self,tbl, col_val_list, seq):
        seqlist = []
        curs_created = 0
        for cols, vals in col_val_list:
            if not self.curs:
                assert (seq)
                self.curs = self.conn.cursor ()
                curs_created = 1
# Stick these back in if DB doesn't support SERIAL types
# Also used to do copy.copy of passed-in cols.  Not still needed?
#            if (seq):
#                cols.append ('seq')
#                vals.append ('COALESCE((SELECT MAX(seq) FROM ' + tbl + '), 0)
# + 1')

            cmd = self.mk_insert (tbl, cols, vals)
            inserted = 0
            try:
                self.curs.execute (cmd)
                inserted = 1
            except pgdb.DatabaseError, err:
                # XXX check this as duplicate.  No good portable way?
                dup_err = \
                "ERROR:  Cannot insert a duplicate key into unique index"
                err_str = err.args[0]
                if (-1 == string.find (err_str,dup_err) or not curs_created):
                    print "DB err", err
                    raise pgdb.DatabaseError(err)
                self.conn.rollback ()
                self.curs = self.conn.cursor ()

            if (seq):
                if inserted:
                    sel_cmd = "SELECT currval('" + tbl + "_seq_seq')"
                else:
                    whlist = join_list (map (lambda c,v: c + '=' + v,
                                             cols, vals), (" and "))
                    sel_cmd = "SELECT seq from " + tbl + " where " + whlist
#                   print sel_cmd # for verifying these use index scans
#                   self.curs.execute ('EXPLAIN ' + sel_cmd)
                self.curs.execute (sel_cmd)

                seqs = self.curs.fetchone ()
                if seqs == None:
                    raise "Error: cannot find just-inserted " + sel_cmd
                # XXX probably should have notion of key fields, and
                # only query on them?  But what does it mean to have nonkey
                # fields that can vary in tables like these, and how to
                # merge, say, two different fuller_names?
                assert (len(seqs) == 1)
                seqlist.append (seqs[0])
            if (curs_created):
                self.conn.commit ()
                self.curs = None
        return seqlist

    def run_one (self, table, seq = 0, cont = defcont):
        list = self.massage_marc (table, cont)
        return self.exec_querylist (table, list, seq)

#  sometimes MARC data redundantly encodes relations (e.g. 700 both with
#  and w/out $t field.)  Actually sometimes used for generating
#  author-title entries, which we don't support.  XXX relate_m2m code
#  could be clearer.

    def relate_m2m (self,map_tbl, map_col_nm, map_nos, rel_col_nm,
                    relator_dict, bib_no):
        l = []
        for i in range (len(map_nos)):
            try:
                rel = relator_dict[i]
            except KeyError:
                rel = "''"
                relator_dict[i] = rel
                # XXX hack to allow us to test below more easily...
            do_continue = 0
            try:
                old = map_nos.index(map_nos[i])
                if  old < i and relator_dict[old] == rel:
#                   print 'WARNING: ', map_tbl, 'repeated mapping', \
# map_nos[i], map_nos[old], bib_no
                    do_continue = 1
            except ValueError: pass # index above must have failed
            if do_continue:
                continue
# (Python 1.5 docs: The restriction on [continue] occurring in the try
# clause is implementer's laziness and will eventually be lifted. 
            cols = ['bibno', map_col_nm, rel_col_nm]
            vals = ["%s" % bib_no, "%s" % map_nos[i], rel]
            cmd = "INSERT INTO %s (%s) VALUES (%s)" % (map_tbl,
                                                       join_list (cols,','),
                                                       join_list (vals, ','))
            l.append (cmd)
        return l

    def partition_marc (self, marcdat):
        self.partitioned_marc = {}
        for tbl in FieldDict.tbl_to_dict.keys ():
            self.partitioned_marc[tbl] = {}
        for (field, fdat) in marcdat.fields.items ():
            self.partitioned_marc[FieldDict.field_to_tbl.lookup_field
                                  (field)][field] = fdat

    def run (self):
        self.ensure_callno_present ()
        # many-to-many relations
        m2ms = [('auth_personal', 'authno', 'relator'),
                ('auth_corp', 'authno', 'relator'),
                ('auth_mtg', 'authno', 'relator'),
                ('subj', 'subjno', None),
                ('series', 'seriesno', 'vol')]
        m2m_nos = []
        rel_dict = {}
        
        for (tbl, mapcol, relator) in m2ms:
            l = self.massage_marc (tbl)
            if relator <> None:
                (l, rel_dict[tbl]) = calc_relator_dict (l, relator)
            m2m_nos.append (self.exec_querylist (tbl, l, 1))

# start main transaction. The transactions above aren't logically required
# to be part of the main transaction (since if we fail anywhere up to here,
# they can be restarted and return the correct authnos and subjnos), which
# is good, since they can have commands that fail and abort the current
# xaction.  This code would have fewer special cases, but be less ||izable,
# if we had nested xactions.

        self.curs = self.conn.cursor ()
        # compose the main bib entry, retrieve main.seq
        bib_nos = self.run_one ('main', 1)
        assert (len(bib_nos) == 1)
        bib_no = bib_nos[0]
        # compose title list, stick into title
        add_bibno = lambda cols, vals, fieldno, bib_no = bib_no: \
                    (cols + ["bibno"], vals + ["%d" % bib_no])
        add_fieldno_cont = lambda cols, vals, fieldno, bib_no = bib_no: \
                           (cols + ["bibno", "field"], vals +
                            [("%d" % (bib_no)), ("%d" % (fieldno))])
        def callno_cont (cols, vals, fieldno, bib_no=bib_no):
            cols = cols + ["bibno"]
            vals = vals + ["%d" % bib_no]
            klass = my_find ('class', cols, vals)
            item = my_find ('item', cols, vals, '')
            print_call (klass + item)
            cv = (cols + call.field_names, vals + call.parse (klass, item))
            return cv
               
        table_list = [
            ('call_no', callno_cont),
            ('title', add_bibno),
            ('notes',  add_fieldno_cont),
            ('phys_descr', add_bibno),
            ('pub_info', add_bibno),
            ('isbn', add_bibno),
            ('electronic_link', add_bibno),
            ('misc', add_fieldno_cont)]

        stmt_list = []
        for tbl, cont in table_list:
            l = self.massage_marc (tbl, cont)
            for cols, vals in l:
                stmt_list.append (self.mk_insert (tbl, cols, vals))

        for i in range (len(m2m_nos)):
            (tbl, mapcol, relator) = m2ms[i]
            if relator <> None:
                stmt_list = stmt_list + (
                    self.relate_m2m (tbl + '_map', mapcol, m2m_nos[i],
                                     relator,rel_dict [tbl], bib_no))
            else:
                for n in m2m_nos[i]:
                    cmd = "INSERT INTO %s_map (bibno, %s) VALUES (%d,%d)" % \
                          (tbl, mapcol, bib_no, n)
                    stmt_list.append (cmd)
        self.exec_simplelist (stmt_list)
        self.conn.commit ()
        self.curs = None
    def ensure_callno_present (self):
        # Lucien front end requires callno to be present, or the record
        # can't be displayed.  So, we generate a W callno if needed from
        # sequence w_uncataloged XXX we should record this in .edit file,
        # so W call #s will be stable across imports
        
        if len(self.partitioned_marc['call_no']) == 0:
            curs = self.conn.cursor ()
            curs.execute ("select nextval('w_uncataloged')")
            w = curs.fetchall ()
            klass = 'W' + str(w[0][0])
            item = ' ' + cur_year ()
            self.partitioned_marc['call_no'][50] = [
                (' ', '4', [('a', klass),('b',item)])]
            del curs

import time
def cur_year ():
    # One could quibble about what happens in the last several hours of a year.
    return time.strftime ('%Y', time.gmtime(time.time()))

def disp_marc_field (m_fieldarr):
    for f in m_fieldarr:
        print f[0], f[1],
        for s in f[2]:
            print "$", s[0], s[1],
        print

# XXX should recycle FieldDict tables?
title_fields = (245,)
edtn_fields = (250,260,300, 20)

def disp_marc_fields (m, f):
    for i in f:
        if m.fields.has_key (i):
            print i,
            disp_marc_field (m.fields [i])

def disp_marc (m):
    disp_marc_fields (m,title_fields)
    disp_marc_fields (m,edtn_fields)

# XXX del_marc_edtn should sometimes delete notes (e.g.,
# 500 "The deluxe first edition ... is limited to three hundred individually
#  signed and numbered copies"--P. [1]),
# and sometimes not (500 "Some informal remarks towards the modular
# calculus")

def del_marc_edtn (m):
    for i in edtn_fields:
        try:
            del m.fields[i]
        except KeyError:
            pass


def extract_db (fn):
    i = string.find (fn, '_')
    if i == -1:
        print "Unable to extract db from ", fn
        return ""
    return fn [0:i]

def proc_single_MARC_file (fn, conn):
    db = extract_db (fn)
    f = open (fn)
    mdat = zmarc.MARC(f.read ())
    try:
        f = open (fn[:-fn_ext_len] + isbn_ext)
        isbn = f.read ()
        if isbn == "":
            isbn = None
    except IOError:
        isbn = None
    try:
        f = open (fn[:-fn_ext_len] + edit_ext)
        edit = f.readlines ()
    except IOError:
        edit = []
    for edit_line in edit:
        if edit_line [0] == '-':
            try:
                del mdat.fields[string.atoi(edit_line[1:])]
            except KeyError: pass
    MARC_to_SQL (mdat, conn, isbn, db)

    


class MMarcProc:
    def __init__ (self, records, dbconn, interactive, db, isbn=None):
        self.records = records
        self.dbconn = dbconn
        self.interactive = interactive
        self.db = db
        self.isbn = isbn
        self.mdat = [None] * len (records)
        self.disp_base = 0
        self.disp_incr = 5
    def disp (self):
        for i in range (self.disp_base, min (len(self.mdat), self.disp_base + self.disp_incr)):
            if self.mdat [i] == None:
                if self.records[i].syntax <> 'USMARC':
                    print "Bad syntax for record", i, self.records[i].syntax
                    continue
                self.mdat [i] = zmarc.MARC(self.records[i].data)
            print "Record", i + 1, ":", 
            disp_marc (self.mdat[i])
    def run (self):
        self.disp ()

        if self.interactive or test:
            while 1:
                try:
                    wrong_edition = 0
                    val = raw_input ()
                    if len(val) == 0:
                        return
                    if val[0] == 'x':
                        wrong_edition = 1
                        val = val[1:]
                    elif val[0] == 'n':
                        self.disp_base = min (self.disp_base + self.disp_incr,
                                              len (self.mdat) - 1)
                        self.disp ()
                        continue
                    elif val[0] == 'p':
                        self.disp_base = max (0,
                                              self.disp_base - self.disp_incr)
                        self.disp ()
                        continue
                    num = string.atoi (val)
                    print num
                    if num <= 0:
                        print "Ignoring"
                        return
                    if num > len(self.mdat):
                        print "Out of range"
                        continue
                    if self.mdat [num - 1] == None:
                        print "Record", num, "not yet retrieved!"
                        continue
                except ValueError:
                    print "Bad input"
                    continue
                if wrong_edition:
                    del_marc_edtn (self.mdat[num-1])

                MARC_to_SQL (self.mdat[num-1], self.dbconn, self.isbn, self.db)

                return
        else:
            raise "No longer implemented!"
#              if l[0][0:4] == 'isbn': # XXX what did this do?  
#                  isbn = l[0][5:]
#              for i in range(1,len(l)):
#                  MARC_to_SQL (mdat[i-1], conn, isbn, db)


def run_interactive_loop (dbconn):
    conn = zoom.Connection (z3950host[z3950ind][1],  z3950host[z3950ind][2])
    conn.databaseName = z3950host[z3950ind][3]
    conn.preferredRecordSyntax = 'USMARC'
    db = z3950host[z3950ind][0]
    while 1:
        isbn = None
        raw = raw_input ("Query:")
        if len (raw) == 0:
            break
        if raw[0] == '\033':
            (type, data) = cuecat_inp.decode (raw)
            if type <> "IBN" and type <> "IB5":
                print "Unknown barcode type ", type, data
                continue
            (ok,isbn) = book_nos.bookland_to_isbn (data, type == "IB5")
            if not ok:
                continue
            query = 'ISBN="%s"' % (isbn,)
        else:
            query = raw
        try:
            res = conn.search (zoom.Query ('CCL', query))
        except zoom.QuerySyntaxError:
            print "Syntax Error"
            continue
        if len (res) == 0:
            print "No records"
        else:
            MMarcProc (res, dbconn, 1, db, isbn).run ()
    conn.close ()


def get_conn ():
    libstring = util.get_libname ()
    print libstring
    return pgdb.connect (libstring)

def proc_one_file (conn, fn):
    if fn[-1] == '~':
        print "Skipping backup file", fn
    elif fn[-fn_ext_len:] == marc_ext:
        proc_single_MARC_file (fn, conn)
    elif fn[-fn_ext_len:] == isbn_ext or fn[-fn_ext_len:] == edit_ext:
        pass
    else:
        f = open(fn)
        data = f.read ()
        db = extract_db (fn)
        MMarcProc (data, conn, 0, db).run ()
    
import Queue
import threading

class ImpThread (threading.Thread):
    def __init__ (self, fn_queue):
        threading.Thread.__init__ (self)
        self.fn_queue = fn_queue
        
    def run (self):
        conn = get_conn ()
        while 1:
            try:
                fn = self.fn_queue.get_nowait ()
                proc_one_file (conn, fn)
            except Queue.Empty:
# Actually, Queue.Empty, under 1.52, just means that someone else had
# the queue locked. It's more idiomatic to drop a token into the queue
# to indicate when to quit, and to use a blocking get, and would perform
# a little better.
                if self.fn_queue.empty ():
                    print "WARNING: Returning normally"
                    return
                else: pass # False alarm.
            except:
                print "WARNING: exception importing",  traceback.print_exc ()

        
def run_main ():
    if len(sys.argv) > 1:
        if use_threads:
            fn_queue = Queue.Queue (len (sys.argv))
            for fn in sys.argv[1:]:
                fn_queue.put (fn)
            thread_list = []
            for i in range (n_threads):
                thr = ImpThread (fn_queue)
                thr.start ()
                thread_list = thread_list + [thr]
            print "Threads started", thread_list
            for thr in thread_list:
                thr.join ()
        else:
            conn = get_conn ()
            for fn in sys.argv[1:]:
                proc_one_file (conn, fn)
    else:
        run_interactive_loop (get_conn ())


if __name__ == '__main__':
    if 1:
        run_main ()
    else:
        import profile
        import pstats
        prof_fn  = 'prof_data'
        profile.run ('run_main ()', prof_fn)
        foo = pstats.Stats (prof_fn)
        foo.sort_stats ('cumulative')
        foo.print_stats ()


