# Tyrannioware: a book cataloging program
# Copyright (C) 2001-2 Aaron Lav

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import os
import types
import string

def get_libname (user = os.environ.get ("USER", None)):
    libname = os.environ.get ("LIBRARY_NAME", "books")
    return ':' + libname + ':' + user

def quote_str (s):
    if type(s) == types.StringType:
        s = string.replace (s, "\\", "\\\\")
        s = string.replace (s, r"'", r"\'")
    else:
        s = str(s) # for numeric fields
    return "'" + s + "'"

def quote_list(vals):
    return map (quote_str, vals)
